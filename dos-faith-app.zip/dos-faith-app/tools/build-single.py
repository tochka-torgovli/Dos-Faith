#!/usr/bin/env python3
"""Собирает www/ в один HTML-файл для быстрого просмотра или публикации одной страницей.

Запуск из корня проекта:  python3 tools/build-single.py [результат.html]
Ссылка на сервер каталога в сборке отключается, остальное работает как в приложении.
"""
import json
import pathlib
import re
import sys

root = pathlib.Path(__file__).resolve().parent.parent / 'www'
out = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else root.parent / 'dist-single.html'

read = lambda p: (root / p).read_text(encoding='utf-8')

html = read('index.html')
body = html.split('<body>', 1)[1].rsplit('</body>', 1)[0]
body = re.sub(r'<script\b[^>]*></script>\s*', '', body)
body = re.sub(r'<!--.*?-->\s*', '', body, flags=re.S)

catalog = read('config/catalog.js')
games = re.findall(r'"file":"(js/games/[a-z0-9-]+\.js)"', catalog)
order = ['config/app.config.js', 'config/catalog.js', 'js/catalog.js', 'js/core.js'] \
    + games + ['js/admin.js', 'js/app.js', 'js/boot.js']

parts = []
for name in order:
    text = read(name)
    if name == 'config/app.config.js':
        text = re.sub(r"remoteCatalogUrl:\s*'[^']*'", "remoteCatalogUrl: ''", text)
    parts.append('/* ==== %s ==== */\n%s' % (name, text))
script = '\n'.join(parts)
assert '</script' not in script.lower(), 'в коде есть закрывающий тег script'

title = re.search(r'<title>(.*?)</title>', html, re.S).group(1)
fonts = re.search(r'<link rel="stylesheet" href="(https://fonts[^"]+)">', html).group(1)
page = (
    '<title>%s</title>\n<meta name="claude:viewport-fit-sides" content="cover">\n'
    '<link rel="stylesheet" href="%s">\n<style>\n%s\n</style>\n%s\n<script>\n%s\n</script>\n'
    % (title, fonts, read('css/app.css'), body.strip(), script)
)
out.write_text(page, encoding='utf-8')
print('готово: %s (%d КБ), файлов в сборке: %d' % (out, len(page.encode('utf-8')) // 1024, len(order)))
