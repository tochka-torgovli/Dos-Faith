/* Каталог игр и сообщений DOS& FAITH.
   Файл читает приложение при запуске и, если в app.config.js задана ссылка remoteCatalogUrl, скачивает заново с сервера.
   Правится вручную или через админку: вкладка «Публикация» выдаёт готовый текст файла целиком.
   Здесь только данные. Код игр лежит в js/games. */
window.DF_CATALOG = {
  "schema": 1,
  "rev": 1,
  "updatedAt": "2026-11-11",
  "app": {
    "latest": "0.2.0",
    "min": "0.1.0",
    "storeUrl": "",
    "message": ""
  },
  "announcement": {
    "id": "",
    "text": "",
    "level": "info",
    "from": "",
    "to": ""
  },
  "games": [
    {"id":"durak","file":"js/games/durak.js","enabled":true,"order":10,"badge":""},
    {"id":"sudoku","file":"js/games/sudoku.js","enabled":true,"order":20,"badge":""},
    {"id":"match3","file":"js/games/match3.js","enabled":true,"order":30,"badge":""},
    {"id":"chess","file":"js/games/chess.js","enabled":true,"order":40,"badge":""},
    {"id":"nardy","file":"js/games/nardy.js","enabled":true,"order":50,"badge":""},
    {"id":"battleship","file":"js/games/battleship.js","enabled":true,"order":60,"badge":""}
  ]
};
