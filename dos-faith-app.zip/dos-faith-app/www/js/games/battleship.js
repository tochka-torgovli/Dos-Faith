'use strict';
/* ---------- Battleship ---------- */
function runBattleship(c,box,alive,onClose,again){
  const LENS=[4,3,3,2,2,2,1,1,1,1],COL='АБВГДЕЖЗИК';
  const later=(f,ms)=>setTimeout(()=>{if(alive())f()},ms);
  const nb=i=>{const r=i/10|0,k=i%10,o=[];for(let a=-1;a<=1;a++)for(let b=-1;b<=1;b++){if(!a&&!b)continue;const rr=r+a,kk=k+b;if(rr>=0&&rr<10&&kk>=0&&kk<10)o.push(rr*10+kk)}return o};
  const nb4=i=>{const r=i/10|0,k=i%10,o=[];if(r>0)o.push(i-10);if(r<9)o.push(i+10);if(k>0)o.push(i-1);if(k<9)o.push(i+1);return o};
  const clear=(occ,i)=>occ[i]===-1&&nb(i).every(n=>occ[n]===-1);
  function layout(){
    for(let tr=0;tr<400;tr++){const occ=Array(100).fill(-1),ships=[];let ok=true;
      for(const L of LENS){let done=false;
        for(let t=0;t<150&&!done;t++){const hor=Math.random()<.5,r=Math.random()*(hor?10:11-L)|0,k=Math.random()*(hor?11-L:10)|0;
          const cells=Array.from({length:L},(_,j)=>hor?r*10+k+j:(r+j)*10+k);
          if(cells.every(i=>clear(occ,i))){cells.forEach(i=>occ[i]=ships.length);ships.push({cells,hits:0,sunk:false});done=true}}
        if(!done){ok=false;break}}
      if(ok)return {occ,ships,shots:Array(100).fill(0)}}
    return {occ:Array(100).fill(-1),ships:[],shots:Array(100).fill(0)}}
  function shoot(T,i){const s=T.occ[i];
    if(s<0){T.shots[i]=1;return 'miss'}
    T.shots[i]=2;const sh=T.ships[s];sh.hits++;
    if(sh.hits===sh.cells.length){sh.sunk=true;sh.cells.forEach(j=>nb(j).forEach(n=>{if(T.shots[n]===0)T.shots[n]=1}));return 'sunk'}
    return 'hit'}
  const left=T=>T.ships.filter(s=>!s.sunk).length;
  const cname=i=>COL[i%10]+((i/10|0)+1);
  let me=layout(),en=null,phase='place',turn='me',busy=false,over=null,msg='';
  function botPick(){
    const hits=[];me.ships.forEach(s=>{if(!s.sunk)s.cells.forEach(i=>{if(me.shots[i]===2)hits.push(i)})});
    let cand=[];
    if(hits.length===1)cand=nb4(hits[0]);
    else if(hits.length>1){hits.sort((a,b)=>a-b);const lo=hits[0],hi=hits[hits.length-1],horiz=(lo/10|0)===(hi/10|0);
      cand=horiz?[lo-1,hi+1].filter(x=>(x/10|0)===(lo/10|0)):[lo-10,hi+10]}
    cand=cand.filter(i=>i>=0&&i<100&&me.shots[i]===0);
    if(!cand.length){const free=[];for(let i=0;i<100;i++)if(me.shots[i]===0)free.push(i);
      const par=free.filter(i=>((i/10|0)+i%10)%2===0),pool=par.length?par:free;return pool[Math.random()*pool.length|0]}
    return cand[Math.random()*cand.length|0]}
  function tapEnemy(i){if(phase!=='battle'||turn!=='me'||busy||over||en.shots[i])return;
    const r=shoot(en,i);
    if(!left(en)){over='win';render();return}
    if(r==='miss'){msg='Мимо ('+cname(i)+'). Стреляет '+c.name;turn='bot';busy=true;render();later(botTurn,800)}
    else{msg=(r==='sunk'?'Потопил! ':'Попал! ')+'Стреляйте ещё';render()}}
  async function botTurn(){
    for(;;){
      const i=botPick(),r=shoot(me,i);
      if(!left(me)){over='lose';busy=false;msg='';render();return}
      if(r==='miss'){msg=c.name+': '+cname(i)+', мимо. Ваш выстрел';turn='me';busy=false;render();return}
      msg=c.name+': '+cname(i)+', '+(r==='sunk'?'корабль потоплен':'попал')+'. Стреляет ещё';render();
      await sleep(850);if(!alive())return}}
  function gridEl(T,mine,onTap,cls){const g=el('div','bgrid '+cls);
    for(let i=0;i<100;i++){const b=el(onTap?'button':'div','wc');if(onTap)b.type='button';
      const s=T.shots[i],sh=T.occ[i]>=0,sunk=sh&&T.ships[T.occ[i]].sunk;
      if(s===2)b.classList.add(sunk?'sk':'ht');else if(s===1)b.classList.add('mi');else if(mine&&sh)b.classList.add('sh');
      if(onTap){b.setAttribute('aria-label',cname(i)+(s===2?', попадание':s===1?', мимо':''));b.onclick=()=>onTap(i)}
      g.appendChild(b)}
    return g}
  function render(){
    box.innerHTML='';
    if(phase==='place'){
      box.appendChild(el('div','dmsg','Ваш флот расставлен. Можно перемешать.'));
      const g=gridEl(me,true,null,'lg');g.style.marginTop='10px';box.appendChild(g);
      const act=el('div','btns');act.style.marginTop='12px';
      const a=el('button','btn','Перемешать');a.type='button';a.onclick=()=>{me=layout();render()};
      const b=el('button','btn gold','В бой!');b.type='button';b.onclick=()=>{en=layout();phase='battle';turn='me';msg='Ваш выстрел';render()};
      act.append(a,b);box.appendChild(act);
      box.appendChild(el('p','note','10 кораблей: один на 4 клетки, два на 3, три на 2 и четыре на 1. Корабли не касаются друг друга. Попал — стреляете снова.'));
      return}
    const st=el('div','stat');st.appendChild(el('span','','Кораблей у соперника: '+left(en)));st.appendChild(el('span','','У вас: '+left(me)));box.appendChild(st);
    box.appendChild(el('div','dmsg',over?'':msg));
    box.appendChild(el('div','lbl','Поле соперника: '+c.name));
    box.appendChild(gridEl(en,false,tapEnemy,'lg'));
    box.appendChild(el('div','lbl','Ваш флот'));
    box.appendChild(gridEl(me,true,null,'sm'));
    if(over)result(box,over==='win'?'Флот потоплен!':'Ваш флот потоплен',over==='win'?'Вы победили '+c.name:c.name+' победил(а)',again);
  }
  render();
}

registerGame("battleship",{
  name:"Морской бой",
  desc:"10 кораблей, попал — стреляй ещё",
  icon:"<svg viewBox=\"0 0 34 34\"><rect x=\"5\" y=\"5\" width=\"24\" height=\"24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\"/><path d=\"M5 13h24M5 21h24M13 5v24M21 5v24\" stroke=\"currentColor\" stroke-width=\"1\" opacity=\".45\"/><rect x=\"6.5\" y=\"14.5\" width=\"13\" height=\"5\" fill=\"var(--accent)\"/><path d=\"M23 7l4 4m0-4l-4 4\" stroke=\"var(--bad)\" stroke-width=\"2\"/><circle cx=\"25\" cy=\"25\" r=\"1.8\" fill=\"currentColor\"/></svg>",
  run:runBattleship
});
