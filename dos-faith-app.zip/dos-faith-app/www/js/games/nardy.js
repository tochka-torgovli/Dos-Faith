'use strict';
/* ---------- Backgammon (short nardy) ---------- */
function runNardy(c,box,alive,onClose,again){
  const mk=()=>{const a=Array(26).fill(0);a[24]=2;a[13]=5;a[8]=3;a[6]=5;return a};
  const A=mk(),O=mk();   /* index = distance to bear off for that side, 25 = bar, 0 = off */
  const later=(f,ms)=>setTimeout(()=>{if(alive())f()},ms);
  const canOff=X=>{for(let i=7;i<=25;i++)if(X[i])return false;return true};
  const pips=X=>{let s=0;for(let i=1;i<=25;i++)s+=i*X[i];return s};
  function single(X,Y,i,d){
    if(!X[i])return null;if(X[25]&&i!==25)return null;
    const t=i-d;
    if(t>=1){const o=Y[25-t];return o>=2?null:{to:t,hit:o===1}}
    if(!canOff(X))return null;
    if(t<0){for(let j=i+1;j<=6;j++)if(X[j])return null}
    return {to:0,hit:false}}
  function doMove(X,Y,from,to,hit){X[from]--;if(to>0)X[to]++;else X[0]++;if(hit){Y[25-to]--;Y[25]++}}
  function maxUse(X,Y,dice){let best=0;const seen=new Set();
    for(let k=0;k<dice.length;k++){const d=dice[k];if(seen.has(d))continue;seen.add(d);
      const rest=dice.slice(0,k).concat(dice.slice(k+1));
      for(let i=1;i<=25;i++){const m=single(X,Y,i,d);if(!m)continue;
        const X2=X.slice(),Y2=Y.slice();doMove(X2,Y2,i,m.to,m.hit);
        const v=1+maxUse(X2,Y2,rest);if(v>best)best=v;if(best===dice.length)return best}}
    return best}
  function legalMoves(X,Y,dice){const mx=maxUse(X,Y,dice);if(!mx)return [];
    const out=[],seen=new Set();
    for(let k=0;k<dice.length;k++){const d=dice[k];if(seen.has(d))continue;seen.add(d);
      const rest=dice.slice(0,k).concat(dice.slice(k+1));
      for(let i=1;i<=25;i++){const m=single(X,Y,i,d);if(!m)continue;
        const X2=X.slice(),Y2=Y.slice();doMove(X2,Y2,i,m.to,m.hit);
        if(1+maxUse(X2,Y2,rest)===mx)out.push({from:i,die:d,to:m.to,hit:m.hit})}}
    if(mx===1&&dice.length===2&&dice[0]!==dice[1]){const big=Math.max(...out.map(m=>m.die));return out.filter(m=>m.die===big)}
    return out}
  function ev(B,M){let s=(pips(M)-pips(B));
    s+=B[0]*6-M[0]*6;s+=M[25]*14-B[25]*14;
    for(let i=1;i<=24;i++){
      if(B[i]>=2)s+=3+(i<=6?2:0);
      if(B[i]>3)s-=(B[i]-3)*2;
      if(B[i]===1){const bp=25-i;let pen=0;for(let p=bp+1;p<=25;p++){if(M[p]){const dist=p-bp;pen=Math.max(pen,dist<=6?10:dist<=12?4:0)}}s-=pen}}
    return s}
  let phase='roll',dice=[],shown=[],sel=-1,lm=[],over=null,msg='Ваш бросок';
  const rollTwo=()=>{const a=1+Math.random()*6|0,b=1+Math.random()*6|0;return a===b?[a,a,a,a]:[a,b]};
  function roll(){if(phase!=='roll')return;shown=rollTwo();dice=shown.slice();sel=-1;lm=legalMoves(A,O,dice);
    if(!lm.length){phase='pass';msg='Нет возможных ходов. Ход переходит к '+c.name;render();later(botTurn,1500)}
    else{phase='move';msg='Выберите шашку';render()}}
  function tap(p){if(phase!=='move')return;
    if(sel>=0&&p!==sel){const cand=lm.filter(m=>m.from===sel&&m.to===p&&p>0);if(cand.length){play(cand[0]);return}}
    sel=lm.some(m=>m.from===p)&&sel!==p?p:-1;render()}
  function play(m){doMove(A,O,m.from,m.to,m.hit);dice.splice(dice.indexOf(m.die),1);sel=-1;
    if(A[0]===15){over='win';phase='over';render();return}
    lm=dice.length?legalMoves(A,O,dice):[];
    if(!lm.length){phase='pass';msg=dice.length?'Больше ходов нет':'Ход закончен';render();later(botTurn,dice.length?1300:700)}
    else render()}
  function offMove(){const cand=lm.filter(m=>m.from===sel&&m.to===0).sort((a,b)=>a.die-b.die);if(cand.length)play(cand[0])}
  async function botTurn(){
    if(over)return;phase='bot';sel=-1;lm=[];dice=[];shown=[];msg=c.name+' бросает кости…';render();
    await sleep(800);if(!alive())return;
    shown=rollTwo();dice=shown.slice();msg=c.name+' ходит';render();await sleep(800);if(!alive())return;
    while(dice.length){
      const ms=legalMoves(O,A,dice);
      if(!ms.length){msg=c.name+': ходов нет';render();await sleep(900);if(!alive())return;break}
      let best=null,bv=-1e9;
      for(const m of ms){const O2=O.slice(),A2=A.slice();doMove(O2,A2,m.from,m.to,m.hit);const v=ev(O2,A2)+Math.random()*1.5;if(v>bv){bv=v;best=m}}
      doMove(O,A,best.from,best.to,best.hit);dice.splice(dice.indexOf(best.die),1);render();
      if(O[0]===15){over='lose';phase='over';render();return}
      await sleep(750);if(!alive())return}
    phase='roll';dice=[];shown=[];msg='Ваш бросок';render()}
  function render(){
    box.innerHTML='';
    const st=el('div','stat');st.appendChild(el('span','','Выведено: '+A[0]+' / '+O[0]));st.appendChild(el('span','sub','Путь: '+pips(A)+' / '+pips(O)));box.appendChild(st);
    const bd=el('div','bgm');
    const TOP=[13,14,15,16,17,18,25,19,20,21,22,23,24],BOT=[12,11,10,9,8,7,25,6,5,4,3,2,1];
    [TOP,BOT].forEach((row,ri)=>row.forEach((p,ci)=>{
      const bar=ci===6;
      const mine=bar?(ri?A[25]:0):A[p],theirs=bar?(ri?0:O[25]):O[25-p];
      const b=el(bar&&!ri?'div':'button','pt '+(ri?'bt':'tp')+(bar?' bar':(p%2?' alt':'')));
      if(b.tagName==='BUTTON'){b.type='button';b.onclick=()=>tap(p);b.setAttribute('aria-label',bar?'Бар':'Пункт '+p)}
      if(phase==='move'){
        if(sel===p)b.classList.add('sel');
        else if(sel>=0&&p>0&&lm.some(m=>m.from===sel&&m.to===p&&!(bar)))b.classList.add('tg');
        else if(sel<0&&(!bar||ri)&&lm.some(m=>m.from===p))b.classList.add('mv')}
      const n=mine||theirs,cls=mine?'m':'o';
      for(let k=0;k<Math.min(n,5);k++){const ck=el('span','ck '+cls);if(k===4&&n>5)ck.textContent=String(n);b.appendChild(ck)}
      bd.appendChild(b)}));
    box.appendChild(bd);
    const dz=el('div','dice');dz.style.marginTop='12px';
    if(phase==='roll'&&!over){const rb=el('button','btn gold','Бросить кости');rb.type='button';rb.onclick=roll;dz.appendChild(rb)}
    else{const rem=dice.slice();shown.forEach(d=>{const i=rem.indexOf(d),u=i<0;if(!u)rem.splice(i,1);
      const e=el('span','die'+(u?' used':''),String.fromCodePoint(0x267F+d));e.setAttribute('aria-label','Кость '+d);dz.appendChild(e)})}
    if(phase==='move'&&sel>=0&&lm.some(m=>m.from===sel&&m.to===0)){const ob=el('button','btn pri','Вывести шашку');ob.type='button';ob.onclick=offMove;dz.appendChild(ob)}
    box.appendChild(dz);
    box.appendChild(el('div','dmsg',over?'':msg)).style.marginTop='10px';
    box.appendChild(el('p','note','Вы ходите жёлтым по часовой стрелке к дому в правом нижнем углу. Соперник ходит в обратную сторону. Съеденные шашки стоят на баре в центре.'));
    if(over)result(box,over==='win'?'Победа!':'Поражение',over==='win'?'Все 15 шашек выведены':c.name+' вывел(а) все шашки',again);
  }
  render();
}

registerGame("nardy",{
  name:"Нарды",
  desc:"Короткие нарды, 15 шашек у каждого",
  icon:"<svg viewBox=\"0 0 34 34\"><rect x=\"4\" y=\"5\" width=\"26\" height=\"24\" rx=\"3\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\"/><path d=\"M8 6h6l-3 14zM20 6h6l-3 14z\" fill=\"var(--accent)\"/><path d=\"M14 28h6l-3-14z\" fill=\"var(--accent)\"/><circle cx=\"11\" cy=\"24\" r=\"3\" fill=\"var(--gold)\"/><circle cx=\"23\" cy=\"24\" r=\"3\" fill=\"var(--gold)\"/></svg>",
  run:runNardy
});
