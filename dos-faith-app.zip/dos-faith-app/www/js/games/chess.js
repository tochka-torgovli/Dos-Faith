'use strict';
/* ---------- Chess ---------- */
function runChess(c,box,alive,onClose,again){
  const GL={K:'♚︎',Q:'♛︎',R:'♜︎',B:'♝︎',N:'♞︎',P:'♟︎'};
  const NM={K:'король',Q:'ферзь',R:'ладья',B:'слон',N:'конь',P:'пешка'};
  const VAL={P:100,N:320,B:330,R:500,Q:900,K:0};
  const ND=[[1,2],[2,1],[-1,2],[-2,1],[1,-2],[2,-1],[-1,-2],[-2,-1]];
  const KD=[[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]];
  const inb=(r,f)=>r>=0&&r<8&&f>=0&&f<8;
  const opp=x=>x==='w'?'b':'w';
  const sqName=i=>'abcdefgh'[i&7]+(8-(i>>3));
  function start(){const b=Array(64).fill(null),back='RNBQKBNR';
    for(let i=0;i<8;i++){b[i]={c:'b',t:back[i]};b[8+i]={c:'b',t:'P'};b[48+i]={c:'w',t:'P'};b[56+i]={c:'w',t:back[i]}}
    return {b,turn:'w',cas:{wK:1,wQ:1,bK:1,bQ:1},ep:-1}}
  function attacked(b,sq,by){const r=sq>>3,f=sq&7,pr=by==='w'?r+1:r-1;
    for(const df of [-1,1]){if(inb(pr,f+df)){const p=b[pr*8+f+df];if(p&&p.c===by&&p.t==='P')return true}}
    for(const [d1,d2] of ND){const rr=r+d1,ff=f+d2;if(inb(rr,ff)){const p=b[rr*8+ff];if(p&&p.c===by&&p.t==='N')return true}}
    for(const [d1,d2] of KD){const rr=r+d1,ff=f+d2;if(inb(rr,ff)){const p=b[rr*8+ff];if(p&&p.c===by&&p.t==='K')return true}}
    for(const [d1,d2] of KD){let rr=r+d1,ff=f+d2;while(inb(rr,ff)){const p=b[rr*8+ff];
      if(p){if(p.c===by&&(p.t==='Q'||((d1&&d2)?p.t==='B':p.t==='R')))return true;break}rr+=d1;ff+=d2}}
    return false}
  const kingAt=(b,col)=>b.findIndex(p=>p&&p.c===col&&p.t==='K');
  function pseudo(s,col){const b=s.b,out=[];
    for(let i=0;i<64;i++){const p=b[i];if(!p||p.c!==col)continue;const r=i>>3,f=i&7;
      if(p.t==='P'){
        const dir=col==='w'?-1:1,r1=r+dir,home=col==='w'?6:1,last=col==='w'?0:7;
        const add=(t,ep)=>out.push({from:i,to:t,promo:(t>>3)===last,ep:!!ep});
        if(inb(r1,f)&&!b[r1*8+f]){add(r1*8+f);if(r===home&&!b[(r+2*dir)*8+f])add((r+2*dir)*8+f)}
        for(const df of [-1,1]){const ff=f+df;if(!inb(r1,ff))continue;const t=r1*8+ff;
          if(b[t]&&b[t].c!==col)add(t);else if(!b[t]&&t===s.ep)add(t,true)}
      }else if(p.t==='N'||p.t==='K'){
        for(const [dr,df] of (p.t==='N'?ND:KD)){const rr=r+dr,ff=f+df;if(!inb(rr,ff))continue;const t=rr*8+ff;if(!b[t]||b[t].c!==col)out.push({from:i,to:t})}
        if(p.t==='K'){const row=col==='w'?56:0,en=opp(col);
          if(i===row+4&&!attacked(b,i,en)){
            if(s.cas[col+'K']&&!b[row+5]&&!b[row+6]&&b[row+7]&&b[row+7].t==='R'&&b[row+7].c===col&&!attacked(b,row+5,en)&&!attacked(b,row+6,en))out.push({from:i,to:row+6,cas:'K'});
            if(s.cas[col+'Q']&&!b[row+1]&&!b[row+2]&&!b[row+3]&&b[row]&&b[row].t==='R'&&b[row].c===col&&!attacked(b,row+3,en)&&!attacked(b,row+2,en))out.push({from:i,to:row+2,cas:'Q'})}}
      }else{
        for(const [dr,df] of KD){if(p.t==='B'&&!(dr&&df))continue;if(p.t==='R'&&dr&&df)continue;
          let rr=r+dr,ff=f+df;while(inb(rr,ff)){const t=rr*8+ff;if(b[t]){if(b[t].c!==col)out.push({from:i,to:t});break}out.push({from:i,to:t});rr+=dr;ff+=df}}
      }}
    return out}
  function apply(s,m){const b=s.b.slice(),p=b[m.from],cas={...s.cas};let ep=-1;
    b[m.to]=p;b[m.from]=null;
    if(m.ep)b[m.to+(p.c==='w'?8:-8)]=null;
    if(m.promo)b[m.to]={c:p.c,t:'Q'};
    if(p.t==='P'&&Math.abs(m.to-m.from)===16)ep=(m.from+m.to)/2;
    if(m.cas){const rf=m.cas==='K'?m.to+1:m.to-2,rt=m.cas==='K'?m.to-1:m.to+1;b[rt]=b[rf];b[rf]=null}
    if(p.t==='K'){cas[p.c+'K']=0;cas[p.c+'Q']=0}
    [[56,'wQ'],[63,'wK'],[0,'bQ'],[7,'bK']].forEach(([q,k])=>{if(m.from===q||m.to===q)cas[k]=0});
    return {b,turn:opp(s.turn),cas,ep}}
  const legal=s=>{const col=s.turn;return pseudo(s,col).filter(m=>{const n=apply(s,m);return !attacked(n.b,kingAt(n.b,col),opp(col))})};
  const inCheck=s=>attacked(s.b,kingAt(s.b,s.turn),opp(s.turn));
  function evalS(s){let v=0;for(let i=0;i<64;i++){const p=s.b[i];if(!p)continue;const r=i>>3,f=i&7;
    const dc=Math.max(Math.abs(r-3.5),Math.abs(f-3.5));let x=VAL[p.t];
    if(p.t==='P')x+=(p.c==='w'?6-r:r-1)*6+(3.5-dc)*4;
    else if(p.t==='N'||p.t==='B')x+=(3.5-dc)*9;
    else if(p.t==='Q'||p.t==='R')x+=(3.5-dc)*2;
    else x+=dc*4;
    v+=p.c===s.turn?x:-x}return v}
  function search(s,d,a,bt){
    if(d===0)return evalS(s);
    const ms=legal(s);if(!ms.length)return inCheck(s)?-90000-d:0;
    ms.sort((x,y)=>(s.b[y.to]?VAL[s.b[y.to].t]:0)-(s.b[x.to]?VAL[s.b[x.to].t]:0));
    let best=-Infinity;
    for(const m of ms){const v=-search(apply(s,m),d-1,-bt,-a);if(v>best)best=v;if(best>a)a=best;if(a>=bt)break}
    return best}

  let S=start(),moves=[],sel=-1,tg=[],last=null,over=null,reason='',busy=false,msg='Ваш ход. Вы играете белыми.';
  const later=(f,ms)=>setTimeout(()=>{if(alive())f()},ms);
  function status(){moves=legal(S);const chk=inCheck(S);
    const rest=S.b.filter(p=>p&&p.t!=='K');
    if(!moves.length){over=chk?(S.turn==='b'?'win':'lose'):'draw';reason=chk?'Мат':'Пат'}
    else if(!rest.length||(rest.length===1&&(rest[0].t==='B'||rest[0].t==='N'))){over='draw';reason='Недостаточно фигур для мата'}
    return chk}
  function afterMove(){const chk=status();
    if(over){busy=false;render();return}
    if(S.turn==='b'){busy=true;msg=c.name+' думает…';render();later(botMove,450)}
    else{busy=false;msg=(chk?'Шах! ':'')+'Ваш ход.'+(last?' '+c.name+': '+sqName(last.from)+'–'+sqName(last.to)+'.':'');render()}}
  function botMove(){const ms=moves;let best=null,bv=-Infinity;
    for(const m of ms){const v=-search(apply(S,m),2,-Infinity,Infinity)+Math.random()*12;if(v>bv){bv=v;best=m}}
    S=apply(S,best);last=best;afterMove()}
  function go(m){S=apply(S,m);last=m;sel=-1;tg=[];afterMove()}
  function tap(i){if(over||busy||S.turn!=='w')return;const p=S.b[i];
    if(sel>=0){const m=moves.find(x=>x.from===sel&&x.to===i);if(m){go(m);return}}
    if(p&&p.c==='w'){sel=i;tg=moves.filter(x=>x.from===i).map(x=>x.to)}else{sel=-1;tg=[]}
    render()}
  function render(){
    box.innerHTML='';const d=el('div','dk');
    const bd=el('div','cb');const kSq=inCheck(S)?kingAt(S.b,S.turn):-1;
    for(let i=0;i<64;i++){const r=i>>3,f=i&7,p=S.b[i];
      const b=el('button','cs'+((r+f)%2?' d':''));b.type='button';
      if(last&&(i===last.from||i===last.to))b.classList.add('lm');
      if(i===kSq)b.classList.add('ck');
      if(i===sel)b.classList.add('sel');
      if(tg.includes(i)){b.classList.add('tg');if(p)b.classList.add('cap')}
      if(p)b.appendChild(el('span',p.c==='w'?'pw':'pk',GL[p.t]));
      b.setAttribute('aria-label',sqName(i)+(p?', '+(p.c==='w'?'белые ':'чёрные ')+NM[p.t]:''));
      b.onclick=()=>tap(i);bd.appendChild(b)}
    d.appendChild(bd);
    d.appendChild(el('div','dmsg',over?'':msg));
    if(!over){const act=el('div','btns');const x=el('button','btn','Сдаться');x.type='button';x.onclick=()=>{over='lose';reason='Вы сдались';render()};act.appendChild(x);d.appendChild(act)}
    box.appendChild(d);
    if(over)result(box,over==='win'?'Победа!':over==='lose'?'Поражение':'Ничья',reason+(over==='win'?'. '+c.name+' проиграл(а)':over==='lose'?'. '+c.name+' выиграл(а)':''),again);
  }
  status();render();
}

registerGame("chess",{
  name:"Шахматы",
  desc:"Классические правила, вы играете белыми",
  icon:"<svg viewBox=\"0 0 34 34\"><circle cx=\"17\" cy=\"9\" r=\"4.5\" fill=\"currentColor\"/><path d=\"M13 28l2.2-12h3.6L21 28z\" fill=\"currentColor\"/><path d=\"M12 16.5h10\" stroke=\"currentColor\" stroke-width=\"3\" stroke-linecap=\"round\"/><rect x=\"9\" y=\"27\" width=\"16\" height=\"4\" rx=\"1.5\" fill=\"currentColor\"/></svg>",
  run:runChess
});
