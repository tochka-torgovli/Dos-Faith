'use strict';
/* ---------- Durak ---------- */
function runDurak(c,box,alive,onClose,again){
  const S=['♠','♥','♦','♣'],RL={11:'В',12:'Д',13:'К',14:'Т'};
  const deck=[];for(const s of S)for(let r=6;r<=14;r++)deck.push({s,r});shuf(deck);
  const trump=deck[0].s;const P=[],B=[];
  for(let i=0;i<6;i++){P.push(deck.pop());B.push(deck.pop())}
  const val=k=>k.r+(k.s===trump?20:0),srt=h=>h.sort((a,b)=>val(a)-val(b));srt(P);srt(B);
  const beats=(d,a)=>d.s===a.s?d.r>a.r:(d.s===trump&&a.s!==trump);
  const lbl=k=>(RL[k.r]||k.r)+k.s;
  let table=[],attacker='me',limit=Math.min(6,B.length),busy=false,over=null,msg='Ваш ход. Походите любой картой.';
  const fill=h=>{while(h.length<6&&deck.length)h.push(deck.pop());srt(h)};
  const ranks=()=>{const s=new Set();table.forEach(p=>{s.add(p.a.r);if(p.d)s.add(p.d.r)});return s};
  const allDef=()=>table.every(p=>p.d),firstUnd=()=>table.find(p=>!p.d);
  const rm=(h,k)=>{const i=h.indexOf(k);if(i>=0)h.splice(i,1)};
  const playable=k=>{if(over||busy)return false;
    if(attacker==='me')return table.length===0||(table.length<limit&&allDef()&&ranks().has(k.r));
    const u=firstUnd();return !!u&&beats(k,u.a)};
  const taken=()=>table.flatMap(p=>[p.a,p.d].filter(Boolean));
  function checkEnd(){if(deck.length===0){if(!P.length&&!B.length)over='draw';else if(!P.length)over='win';else if(!B.length)over='lose'}if(over){render();return true}return false}
  function cardEl(k,dis,fn){const b=el(fn?'button':'div','pc'+((k.s==='♥'||k.s==='♦')?' red':''));if(fn){b.type='button';b.disabled=dis;if(!dis)b.classList.add('ok');b.onclick=fn}
    b.appendChild(el('span','rk',String(RL[k.r]||k.r)));b.appendChild(el('span','bg',k.s));b.setAttribute('aria-label',lbl(k));return b}
  function render(){
    box.innerHTML='';const d=el('div','dk');
    const top=el('div','dtop');const bh=el('div','row');const bk=el('div','');bk.style.display='flex';bk.style.paddingRight='10px';
    B.forEach(()=>bk.appendChild(el('div','pc back sm')));bh.append(bk,el('span','sub',c.name+': '+B.length));
    const tr=el('div','');tr.style.textAlign='right';
    const tc=el('b','', 'Козырь '+trump);tc.style.color=(trump==='♥'||trump==='♦')?'var(--bad)':'var(--fg)';tr.append(tc,document.createElement('br'),el('span','sub','Колода: '+deck.length));
    top.append(bh,tr);d.appendChild(top);
    const tb=el('div','dtab');table.forEach(p=>{const w=el('div','pair');w.appendChild(cardEl(p.a));if(p.d)w.appendChild(cardEl(p.d));tb.appendChild(w)});
    if(!table.length)tb.appendChild(el('span','sub','Стол пуст'));d.appendChild(tb);
    d.appendChild(el('div','dmsg',over?'':msg));
    const act=el('div','btns');
    if(!over&&!busy&&attacker==='me'&&table.length&&allDef()){const x=el('button','btn pri','Бито');x.onclick=bito;act.appendChild(x)}
    if(!over&&!busy&&attacker==='bot'&&firstUnd()){const x=el('button','btn','Беру');x.onclick=take;act.appendChild(x)}
    d.appendChild(act);
    const h=el('div','hand');P.forEach(k=>h.appendChild(cardEl(k,!playable(k),()=>play(k))));d.appendChild(h);
    box.appendChild(d);
    if(over)result(box,over==='win'?'Вы победили!':over==='lose'?'Дураком остались вы':'Ничья',over==='win'?c.name+' остался(лась) в дураках':over==='lose'?c.name+' выиграл(а) партию':'Карты закончились у обоих',again);
  }
  function later(fn,ms){setTimeout(()=>{if(alive())fn()},ms)}
  function play(k){if(!playable(k))return;rm(P,k);
    if(attacker==='me'){if(!table.length)limit=Math.min(6,B.length);table.push({a:k,d:null});busy=true;msg=c.name+' думает…';render();later(botDefend,800)}
    else{firstUnd().d=k;if(allDef()){busy=true;msg=c.name+' думает…';render();later(botContinue,800)}else render()}}
  function botDefend(){const u=firstUnd();const k=B.filter(x=>beats(x,u.a)).sort((a,b)=>val(a)-val(b))[0];
    if(k){rm(B,k);u.d=k;msg=c.name+' отбился. Подкиньте ещё или нажмите «Бито».';busy=false;render()}
    else{B.push(...taken());srt(B);table=[];fill(P);msg=c.name+' берёт карты. Ваш ход.';busy=false;if(!checkEnd())render()}}
  function bito(){table=[];fill(P);fill(B);attacker='bot';if(checkEnd())return;busy=true;msg=c.name+' ходит…';render();later(botAttack,800)}
  function botAttack(){const k=B.slice().sort((a,b)=>val(a)-val(b))[0];rm(B,k);limit=Math.min(6,P.length);table=[{a:k,d:null}];busy=false;msg=c.name+' ходит '+lbl(k)+'. Отбейте или возьмите.';render()}
  function botContinue(){const k=B.filter(x=>ranks().has(x.r)&&!(x.s===trump&&deck.length>0)).sort((a,b)=>val(a)-val(b))[0];
    if(k&&table.length<limit){rm(B,k);table.push({a:k,d:null});busy=false;msg=c.name+' подкинул '+lbl(k)+'.';render()}
    else{table=[];fill(B);fill(P);attacker='me';busy=false;msg='Бито. Ваш ход.';if(!checkEnd())render()}}
  function take(){P.push(...taken());srt(P);table=[];fill(B);if(checkEnd())return;busy=true;msg='Вы взяли карты. '+c.name+' ходит снова…';render();later(botAttack,900)}
  render();
}

registerGame("durak",{
  name:"Дурак",
  desc:"Подкидной на двоих, 36 карт",
  icon:"<svg viewBox=\"0 0 34 34\"><rect x=\"6\" y=\"5\" width=\"16\" height=\"23\" rx=\"3\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\"/><rect x=\"12\" y=\"8\" width=\"16\" height=\"23\" rx=\"3\" fill=\"var(--surface)\" stroke=\"currentColor\" stroke-width=\"2\"/><path d=\"M20 15c-3-3-6 1-3 4l3 3 3-3c3-3 0-7-3-4z\" fill=\"var(--bad)\"/></svg>",
  run:runDurak
});
