'use strict';
/* ---------- Sudoku ---------- */
function runSudoku(c,box,alive,onClose,again){
  const sh=a=>shuf(a.slice()),g3=[0,1,2],rows=[],cols=[];
  for(const b of sh(g3))for(const r of sh(g3))rows.push(b*3+r);
  for(const s of sh(g3))for(const k of sh(g3))cols.push(s*3+k);
  const dg=sh([1,2,3,4,5,6,7,8,9]);
  const grid=rows.map(r=>cols.map(k=>dg[(r*3+Math.floor(r/3)+k)%9]));
  const given=grid.map(r=>r.map(()=>true));
  sh(Array.from({length:81},(_,i)=>i)).slice(0,42).forEach(i=>{const r=i/9|0,k=i%9;grid[r][k]=0;given[r][k]=false});
  let sel=null,secs=0,done=false;
  const oppT=300+(Math.random()*240|0);
  const iv=setInterval(()=>{if(!alive()||done)return;secs++;const t=$('#sdT');if(t)t.textContent=fmt(secs)},1000);onClose(()=>clearInterval(iv));
  function bad(r,k){const v=grid[r][k];if(!v)return false;
    for(let i=0;i<9;i++){if(i!==k&&grid[r][i]===v)return true;if(i!==r&&grid[i][k]===v)return true}
    const br=r-r%3,bc=k-k%3;for(let i=br;i<br+3;i++)for(let j=bc;j<bc+3;j++)if((i!==r||j!==k)&&grid[i][j]===v)return true;return false}
  function render(){
    box.innerHTML='';
    const st=el('div','stat');st.appendChild(el('span','','Время: '));st.firstChild.appendChild(Object.assign(el('span','',fmt(secs)),{id:'sdT'}));st.appendChild(el('span','sub','Соперник: ≈ '+fmt(oppT)));box.appendChild(st);
    const sg=el('div','sg');
    for(let r=0;r<9;r++)for(let k=0;k<9;k++){
      const b=el('button','sc'+(given[r][k]?' g':'')+(k%3===2&&k<8?' cr':'')+(r%3===2&&r<8?' br':''),grid[r][k]?String(grid[r][k]):'');b.type='button';
      b.setAttribute('aria-label','Строка '+(r+1)+', столбец '+(k+1)+(grid[r][k]?', '+grid[r][k]:', пусто'));
      if(sel){const [sr,sk]=sel;if(sr===r&&sk===k)b.classList.add('s');else if(sr===r||sk===k||(Math.floor(sr/3)===Math.floor(r/3)&&Math.floor(sk/3)===Math.floor(k/3)))b.classList.add('r')}
      if(bad(r,k))b.classList.add('e');
      b.onclick=()=>{sel=[r,k];render()};sg.appendChild(b)}
    box.appendChild(sg);
    const pad=el('div','pad');for(let n=1;n<=9;n++){const b=el('button','',String(n));b.type='button';b.onclick=()=>put(n);pad.appendChild(b)}
    const er=el('button','','⌫');er.type='button';er.setAttribute('aria-label','Стереть');er.onclick=()=>put(0);pad.appendChild(er);box.appendChild(pad);
  }
  function put(n){if(!sel||done)return;const [r,k]=sel;if(given[r][k])return;grid[r][k]=n;render();
    if(grid.every((row,i)=>row.every((v,j)=>v&&!bad(i,j)))){done=true;render();
      result(box,secs<oppT?'Вы быстрее!':'Решено!',(secs<oppT?'Вы':'Ваше время')+' '+fmt(secs)+', '+c.name+' '+fmt(oppT),again)}}
  render();
}

registerGame("sudoku",{
  name:"Судоку",
  desc:"Кто быстрее заполнит сетку",
  icon:"<svg viewBox=\"0 0 34 34\"><rect x=\"5\" y=\"5\" width=\"24\" height=\"24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\"/><path d=\"M13 5v24M21 5v24M5 13h24M5 21h24\" stroke=\"currentColor\" stroke-width=\"1.2\"/><text x=\"17\" y=\"19.5\" font-size=\"9\" text-anchor=\"middle\" font-weight=\"700\" fill=\"var(--accent)\" font-family=\"Manrope,sans-serif\">7</text></svg>",
  run:runSudoku
});
