'use strict';
/* ---------- Match 3 ---------- */
function runMatch3(c,box,alive,onClose,again){
  const N=8,T=6,GL=['♥','▲','■','◆','★','●'],GOAL=1000,oppS=700+(Math.random()*700|0)*1;
  let b=[],score=0,moves=20,pick=null,busy=false;
  const rnd=()=>Math.random()*T|0;
  function matches(g){const s=new Set();
    for(let r=0;r<N;r++){let k=0;while(k<N){let e=k;while(e+1<N&&g[r][e+1]===g[r][k])e++;if(e-k>=2)for(let i=k;i<=e;i++)s.add(r*N+i);k=e+1}}
    for(let k=0;k<N;k++){let r=0;while(r<N){let e=r;while(e+1<N&&g[e+1][k]===g[r][k])e++;if(e-r>=2)for(let i=r;i<=e;i++)s.add(i*N+k);r=e+1}}
    return s}
  function init(){do{b=Array.from({length:N},()=>Array.from({length:N},rnd))}while(matches(b).size||!hasMove())}
  function hasMove(){for(let r=0;r<N;r++)for(let k=0;k<N;k++)for(const [dr,dk] of [[0,1],[1,0]]){const r2=r+dr,k2=k+dk;if(r2>=N||k2>=N)continue;
    [b[r][k],b[r2][k2]]=[b[r2][k2],b[r][k]];const m=matches(b).size>0;[b[r][k],b[r2][k2]]=[b[r2][k2],b[r][k]];if(m)return true}return false}
  function render(pop,shake){
    box.innerHTML='';
    const st=el('div','stat');st.appendChild(el('span','','Очки: '+score+' / '+GOAL));st.appendChild(el('span','','Ходов: '+moves));box.appendChild(st);
    const g=el('div','mg');
    for(let r=0;r<N;r++)for(let k=0;k<N;k++){const v=b[r][k];const t=el('button','tile',v>=0?GL[v]:'');t.type='button';if(v>=0)t.style.color='var(--g'+v+')';
      t.setAttribute('aria-label',v>=0?'Фишка '+GL[v]+', строка '+(r+1)+', столбец '+(k+1):'');
      if(pick&&pick[0]===r&&pick[1]===k)t.classList.add('sel');
      if(pop&&pop.has(r*N+k))t.classList.add('pop');
      if(shake&&shake.has(r*N+k))t.classList.add('shake');
      t.onclick=()=>tap(r,k);g.appendChild(t)}
    box.appendChild(g);
    box.appendChild(el('p','note','Меняйте местами соседние фишки, чтобы собрать 3 и больше в ряд. Цель: '+GOAL+' очков. Соперник набрал '+oppS+'.'));
  }
  async function tap(r,k){if(busy)return;
    if(!pick){pick=[r,k];render();return}
    const [pr,pk]=pick;if(pr===r&&pk===k){pick=null;render();return}
    if(Math.abs(pr-r)+Math.abs(pk-k)!==1){pick=[r,k];render();return}
    busy=true;pick=null;
    const sw=()=>{[b[pr][pk],b[r][k]]=[b[r][k],b[pr][pk]]};
    sw();
    if(!matches(b).size){render(null,new Set([pr*N+pk,r*N+k]));await sleep(280);if(!alive())return;sw();render();busy=false;return}
    render();await sleep(150);if(!alive())return;
    let combo=1;
    for(;;){const m=matches(b);if(!m.size)break;
      score+=m.size*10*combo+(m.size>3?(m.size-3)*20:0);combo++;
      render(m,null);await sleep(260);if(!alive())return;
      m.forEach(i=>{b[i/N|0][i%N]=-1});
      for(let col=0;col<N;col++){const keep=[];for(let row=N-1;row>=0;row--)if(b[row][col]>=0)keep.push(b[row][col]);
        for(let row=N-1,i=0;row>=0;row--,i++)b[row][col]=i<keep.length?keep[i]:rnd()}
      render();await sleep(260);if(!alive())return}
    moves--;
    if(!hasMove()){do{b=Array.from({length:N},()=>Array.from({length:N},rnd))}while(matches(b).size||!hasMove());toast('Нет ходов: поле перемешано')}
    render();busy=false;
    if(moves===0){busy=true;const win=score>=oppS;result(box,win?'Вы победили!':score>=GOAL?'Цель достигнута':'Ходы закончились',
      'Ваш счёт '+score+', '+c.name+' '+oppS,again)}
  }
  init();render();
}

registerGame("match3",{
  name:"3 в ряд",
  desc:"20 ходов, больше очков у соперника?",
  icon:"<svg viewBox=\"0 0 34 34\"><circle cx=\"9\" cy=\"17\" r=\"5\" fill=\"var(--g0)\"/><circle cx=\"17\" cy=\"17\" r=\"5\" fill=\"var(--g0)\"/><circle cx=\"25\" cy=\"17\" r=\"5\" fill=\"var(--g0)\"/><circle cx=\"17\" cy=\"27\" r=\"3\" fill=\"var(--g3)\"/><circle cx=\"17\" cy=\"7\" r=\"3\" fill=\"var(--g2)\"/></svg>",
  run:runMatch3
});
