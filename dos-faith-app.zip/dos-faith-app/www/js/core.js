'use strict';
/* Ядро приложения: карта, чаты, вкладки, оболочка игр.
   Игры лежат в js/games/*.js и подключаются через registerGame(). */
const G={};
function registerGame(key,def){G[key]=def}
const $=s=>document.querySelector(s);
const el=(t,c,x)=>{const e=document.createElement(t);if(c)e.className=c;if(x!=null)e.textContent=x;return e};
const clock=()=>{const d=new Date();return String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0')};
const shuf=a=>{for(let i=a.length-1;i>0;i--){const j=Math.random()*(i+1)|0;[a[i],a[j]]=[a[j],a[i]]}return a};
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const fmt=s=>Math.floor(s/60)+':'+String(s%60).padStart(2,'0');
const PLAY='<svg viewBox="0 0 16 16"><path d="M4 2l10 6-10 6z"/></svg>',PAUSE='<svg viewBox="0 0 16 16"><path d="M3 2h4v12H3zM9 2h4v12H9z"/></svg>';

const ME={x:170,y:170},KM=0.05;
const HUES=[200,340,28,150,265,12,95];
const C=[
 {id:1,name:'Айгерим',place:'Көк-Төбе',x:300,y:258,ago:'2 мин назад',share:true,online:true,unread:0,msgs:[
  {me:false,type:'text',text:'Салам! Ты где?',t:'17:52'},{me:true,type:'text',text:'Салем, еду из центра. Встретимся на Көк-Төбе?',t:'17:54'},{me:false,type:'text',text:'Давай, я уже тут 😄',t:'17:55'}]},
 {id:2,name:'Данияр',place:'Зелёный базар',x:215,y:140,ago:'5 мин назад',share:true,online:true,unread:0,msgs:[
  {me:false,type:'text',text:'Скинь потом фотки с выходных',t:'16:20'}]},
 {id:3,name:'Мама',place:'Дом',x:95,y:205,ago:'12 мин назад',share:true,online:false,unread:0,msgs:[
  {me:false,type:'text',text:'Балам, не забудь поужинать 🍲',t:'15:05'}]},
 {id:4,name:'Тимур',place:'Парк Горького',x:260,y:185,ago:'1 мин назад',share:true,online:true,unread:1,msgs:[
  {me:false,type:'invite',game:'match3',t:'18:10',accepted:false}]},
 {id:5,name:'Мадина',place:'',x:0,y:0,ago:'',share:false,online:false,unread:0,msgs:[]},
 {id:6,name:'Санжар',place:'Медеу',x:335,y:305,ago:'20 мин назад',share:true,online:false,unread:0,msgs:[]},
 {id:7,name:'Алия',place:'Достык Плаза',x:175,y:238,ago:'3 мин назад',share:true,online:true,unread:0,msgs:[]}
];
const byId=id=>C.find(c=>c.id===id);
const hue=c=>HUES[(c.id-1)%HUES.length];
function avatar(c,cls){const a=el('div','av'+(cls?' '+cls:''),c.name[0]);a.style.background='hsl('+hue(c)+' 45% 36%)';if(c.online&&cls!=='sm'){a.appendChild(el('span','on'))}return a}
function dist(c){const d=Math.hypot(c.x-ME.x,c.y-ME.y)*KM;return d<1?'≈ '+Math.round(d*10)*100+' м':'≈ '+d.toFixed(1).replace('.',',')+' км'}
function toast(t){const o=el('div','toast',t);o.setAttribute('role','status');document.body.appendChild(o);setTimeout(()=>o.remove(),2200)}

/* ---------- tabs ---------- */
let view='map';
function show(v){view=v;['map','chats','games'].forEach(k=>{$('#v-'+k).hidden=k!==v});document.querySelectorAll('.tab').forEach(t=>t.setAttribute('aria-selected',String(t.dataset.v===v)));$('#main').scrollTop=0;if(v==='chats')renderChats();if(v==='games')renderGames()}
document.querySelectorAll('.tab').forEach(t=>t.addEventListener('click',()=>show(t.dataset.v)));

/* ---------- map ---------- */
let sharing=true,selId=null;
function renderMap(){
  const sel=selId?byId(selId):null;
  let s='<rect class="m-bg" width="400" height="360"/>';
  s+='<ellipse class="m-park" cx="250" cy="188" rx="42" ry="22"/><ellipse class="m-park" cx="110" cy="92" rx="36" ry="20"/>';
  [60,115,170,215].forEach(y=>s+='<line class="m-road" x1="0" x2="400" y1="'+y+'" y2="'+y+'" stroke-width="'+(y===215?7:4)+'"/>');
  [70,160,250,340].forEach(x=>s+='<line class="m-road" x1="'+x+'" x2="'+x+'" y1="0" y2="300" stroke-width="4"/>');
  s+='<path class="m-river" d="M120 0 C140 80 100 150 150 230 S190 280 180 300"/>';
  s+='<path class="m-mtn" d="M0 290 L45 265 L95 285 L150 245 L210 280 L270 235 L330 275 L400 250 L400 360 L0 360Z"/>';
  s+='<path class="m-mtn2" d="M0 325 L70 305 L130 330 L210 300 L290 328 L350 308 L400 322 L400 360 L0 360Z"/>';
  s+='<text class="m-lbl" x="262" y="211">пр. Аль-Фараби</text>';
  s+='<text class="m-lbl" x="96" y="351" letter-spacing="2">ЗАИЛИЙСКИЙ АЛАТАУ</text>';
  s+='<text class="m-lbl" x="372" y="20" font-weight="700">С ↑</text>';
  s+='<g class="'+(sharing?'':'m-dim')+'" transform="translate('+ME.x+' '+ME.y+')"><circle class="m-pulse" r="10"/><circle class="m-me" r="8"/><text class="m-lbl" y="24" text-anchor="middle" font-weight="700">Вы</text></g>';
  C.filter(c=>c.share).forEach(c=>{
    const on=c.id===selId;
    s+='<g class="mk" data-id="'+c.id+'" transform="translate('+c.x+' '+c.y+')" tabindex="0" role="button" aria-label="'+c.name+', '+c.place+'">'
      +'<circle r="22" fill="transparent"/><circle r="15" fill="hsl('+hue(c)+' 45% 36%)" style="stroke:'+(on?'var(--gold)':'var(--surface)')+'" stroke-width="'+(on?4:3)+'"/>'
      +'<text text-anchor="middle" dy="5" font-size="14" font-weight="700" fill="#fff" font-family="Manrope,sans-serif">'+c.name[0]+'</text></g>';
  });
  if(sel&&sel.share){const w=sel.name.length*8+18,x=Math.max(2,Math.min(398-w,sel.x-w/2));
    s+='<g><rect class="m-chip" x="'+x+'" y="'+(sel.y-48)+'" width="'+w+'" height="22" rx="11"/><text class="m-chip-t" x="'+(x+w/2)+'" y="'+(sel.y-33)+'" text-anchor="middle">'+sel.name+'</text></g>'}
  $('#map').innerHTML=s;
  // card
  const card=$('#mcard');card.innerHTML='';card.className='mcard'+(sel?'':' empty');
  if(!sel){card.textContent='Нажмите на друга на карте или в списке ниже'}
  else{
    const r=el('div','row');r.appendChild(avatar(sel));
    const g=el('div','grow');g.appendChild(el('div','nm',sel.name));g.appendChild(el('div','sub',sel.place+' · '+dist(sel)+' · '+sel.ago));r.appendChild(g);card.appendChild(r);
    const b=el('div','btns');
    const w=el('button','btn pri','Написать');w.onclick=()=>openChat(sel.id);
    const v=el('button','btn gold','Бросить вызов');v.onclick=()=>openChat(sel.id,true);
    b.append(w,v);card.appendChild(b);
  }
  // list
  const L=$('#mlist');L.innerHTML='';
  const vis=C.filter(c=>c.share).sort((a,b)=>Math.hypot(a.x-ME.x,a.y-ME.y)-Math.hypot(b.x-ME.x,b.y-ME.y));
  vis.concat(C.filter(c=>!c.share)).forEach(c=>{
    const it=el('button','item'+(c.share?'':' muted'));it.appendChild(avatar(c,'sm'));
    const g=el('div','grow');g.appendChild(el('div','nm',c.name));g.appendChild(el('div','sub',c.share?c.place+' · '+c.ago:'Не делится местоположением'));it.appendChild(g);
    if(c.share)it.appendChild(el('div','dist',dist(c)));
    it.onclick=()=>{if(c.share){selId=c.id;renderMap();$('#main').scrollTop=0}else{toast(c.name+' не включил(а) передачу места')}};
    L.appendChild(it);
  });
}
$('#map').addEventListener('click',e=>{const g=e.target.closest('.mk');if(g){selId=+g.dataset.id;renderMap()}});
$('#map').addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){const g=e.target.closest('.mk');if(g){e.preventDefault();selId=+g.dataset.id;renderMap();const n=document.querySelector('.mk[data-id="'+selId+'"]');if(n)n.focus()}}});
$('#shareSw').addEventListener('click',()=>{sharing=!sharing;const b=$('#shareSw');b.setAttribute('aria-checked',String(sharing));
  $('#shareT').textContent=sharing?'Друзья видят вас':'Вы скрыты';$('#shareS').textContent=sharing?'Показывайте место только тем, кому доверяете':'Контакты не видят, где вы';renderMap()});

/* ---------- chats list ---------- */
function preview(m){if(!m)return 'Начать переписку';if(m.type==='img')return (m.me?'Вы: ':'')+'Фото';if(m.type==='voice')return (m.me?'Вы: ':'')+'Голосовое '+fmt(m.dur);if(m.type==='invite')return 'Вызов: '+Catalog.nameOf(m.game);return (m.me?'Вы: ':'')+m.text}
function updBadge(){const n=C.reduce((a,c)=>a+c.unread,0);const b=$('#tabBadge');b.hidden=!n;b.textContent=n}
function renderChats(){
  const L=$('#clist');L.innerHTML='';
  const order=C.slice().sort((a,b)=>(b.msgs.length>0)-(a.msgs.length>0));
  order.forEach(c=>{
    const last=c.msgs[c.msgs.length-1];
    const it=el('button','item');it.appendChild(avatar(c));
    const g=el('div','grow');g.appendChild(el('div','nm',c.name));g.appendChild(el('div','sub',preview(last)));it.appendChild(g);
    const m=el('div','meta');if(last)m.appendChild(el('span','',last.t));if(c.unread)m.appendChild(el('span','unread',String(c.unread)));it.appendChild(m);
    it.onclick=()=>openChat(c.id);L.appendChild(it);
  });
  updBadge();
}

/* ---------- chat ---------- */
let cur=null,rec=null;
const EMO='😀 😂 🥲 😍 😎 🤝 🙏 👍 👏 🔥 ❤️ 🎉 😢 😡 🤔 😴 🙌 💪 🤗 😅 😉 🥳 😱 🤣 👋 ☕ 🍕 🍲 🎮 🃏 🏆 🏔️ 🌙 ⭐ 🚗 📍 🎵 🌸 🐎 🍉'.split(' ');
EMO.forEach(e=>{const b=el('button','',e);b.type='button';b.setAttribute('aria-label','Эмодзи '+e);b.onclick=()=>{const i=$('#txt');i.value+=e;i.focus();syncSend()};$('#emo').appendChild(b)});
function syncSend(){const has=$('#txt').value.trim().length>0;$('#send').hidden=!has;$('#mic').hidden=has}
$('#txt').addEventListener('input',syncSend);
function openChat(id,menu){
  cur=byId(id);cur.unread=0;
  const a=$('#chatAv');a.innerHTML='';a.appendChild(avatar(cur,'sm'));
  $('#chatName').textContent=cur.name;$('#chatSt').textContent=cur.online?'в сети':(cur.share?'был(а) '+cur.ago:'не в сети');
  $('#chat').hidden=false;$('#emo').hidden=true;$('#gmenu').hidden=true;$('#txt').value='';syncSend();
  drawMsgs();updBadge();
  if(menu)toggleMenu(true);
}
function closeChat(){stopRec(false);$('#chat').hidden=true;cur=null;if(view==='chats')renderChats();else if(view==='map')renderMap()}
$('#chatBack').onclick=closeChat;
function drawMsgs(){
  const box=$('#msgs');box.innerHTML='';
  if(!cur.msgs.length){box.appendChild(el('div','none','Здесь пока пусто. Напишите «Салем!» или бросьте вызов в игру.'));return}
  cur.msgs.forEach(m=>box.appendChild(bubble(m)));
  box.scrollTop=box.scrollHeight;
}
function addMsg(c,m){m.t=clock();c.msgs.push(m);if(cur&&cur.id===c.id)drawMsgs();else{c.unread++;updBadge()}}
function bubble(m){
  const b=el('div','b'+(m.me?' me':'')+(m.type==='img'?' img':''));
  if(m.type==='text'){b.appendChild(document.createTextNode(m.text))}
  else if(m.type==='img'){const i=new Image();i.src=m.src;i.alt='Фото';b.appendChild(i)}
  else if(m.type==='voice'){
    const v=el('div','vm');const p=el('button','pl');p.type='button';p.innerHTML=PLAY;p.setAttribute('aria-label','Воспроизвести');
    const w=el('div','wave');m.bars.forEach(h=>{const i=document.createElement('i');i.style.height=h+'%';w.appendChild(i)});
    const d=el('span','',fmt(m.dur));d.style.fontSize='13px';v.append(p,w,d);b.appendChild(v);
    let iv=null,k=0;p.onclick=()=>{if(iv){clearInterval(iv);iv=null;p.innerHTML=PLAY;return}
      p.innerHTML=PAUSE;const bars=w.children,n=bars.length,step=Math.max(60,m.dur*1000/n);
      if(k>=n){k=0;[...bars].forEach(x=>x.classList.remove('on'))}
      iv=setInterval(()=>{if(k>=n){clearInterval(iv);iv=null;p.innerHTML=PLAY;k=0;[...bars].forEach(x=>x.classList.remove('on'));return}bars[k++].classList.add('on')},step)};
  }
  else if(m.type==='invite'){
    const can=Catalog.canPlay(m.game);const w=el('div','inv');w.appendChild(el('b','','Вызов: '+Catalog.nameOf(m.game)));
    w.appendChild(el('span','',m.me?(m.accepted?cur.name+' принял(а) вызов':'Ждём ответ…'):cur.name+' зовёт сыграть'));
    if(!can){w.appendChild(el('span','','Игра сейчас недоступна'))}
    else if(!m.me&&!m.accepted){const x=el('button','btn gold','Принять');x.type='button';x.onclick=()=>{m.accepted=true;drawMsgs();startGame(m.game,cur)};w.appendChild(x)}
    else if(m.accepted){const x=el('button','btn gold','Играть');x.type='button';x.onclick=()=>startGame(m.game,cur);w.appendChild(x)}
    b.appendChild(w);
  }
  if(m.type!=='img'||true){b.appendChild(el('span','t',m.t||''))}
  return b;
}
const REPL=['Ок 👍','Хахаха 😄','Сейчас, минутку','Давай!','Ты где сейчас?','Супер!','Договорились 🤝'];
function botReply(c,text){setTimeout(()=>addMsg(c,{me:false,type:'text',text}),1100)}
$('#comp').addEventListener('submit',e=>{e.preventDefault();const v=$('#txt').value.trim();if(!v||!cur)return;
  const c=cur;addMsg(c,{me:true,type:'text',text:v});$('#txt').value='';syncSend();botReply(c,c.id===3?'Салем, балам. Береги себя 🤲':REPL[Math.random()*REPL.length|0])});
$('#emoBtn').onclick=()=>{$('#emo').hidden=!$('#emo').hidden;$('#gmenu').hidden=true;const m=$('#msgs');m.scrollTop=m.scrollHeight};
$('#photo').addEventListener('change',e=>{const f=e.target.files[0];e.target.value='';if(!f||!cur)return;
  if(!/^image\//.test(f.type)){toast('Выберите изображение');return}
  const c=cur,fr=new FileReader();fr.onload=()=>{addMsg(c,{me:true,type:'img',src:fr.result});botReply(c,'Классное фото! 🔥')};fr.readAsDataURL(f)});
// voice (simulated recording)
$('#mic').onclick=()=>{if(!cur)return;rec={t:0};$('#comp').hidden=true;$('#recbar').hidden=false;$('#emo').hidden=true;$('#recT').textContent='0:00';
  rec.iv=setInterval(()=>{rec.t++;$('#recT').textContent=fmt(rec.t)},1000)};
function stopRec(send){if(!rec)return;clearInterval(rec.iv);const d=Math.max(1,rec.t);rec=null;$('#recbar').hidden=true;$('#comp').hidden=false;
  if(send&&cur){const c=cur,bars=Array.from({length:26},()=>20+Math.random()*80|0);addMsg(c,{me:true,type:'voice',dur:d,bars});botReply(c,'Послушал(а), отвечу чуть позже 🎧')}}
$('#recCancel').onclick=()=>stopRec(false);$('#recSend').onclick=()=>stopRec(true);
// challenge menu
function toggleMenu(open){const m=$('#gmenu');if(open===undefined)open=m.hidden;m.hidden=!open;if(open){$('#emo').hidden=true;m.innerHTML='';
  const list=Catalog.playable();
  if(!list.length){const b=el('button','','Сейчас нет доступных игр');b.type='button';b.disabled=true;m.appendChild(b)}
  list.forEach(g=>{const b=el('button','',g.name);b.type='button';b.onclick=()=>{m.hidden=true;challenge(cur,g.id,false)};m.appendChild(b)})}}
$('#chatGame').onclick=()=>toggleMenu();
function challenge(c,game,startNow){
  if(!Catalog.canPlay(game)){toast('Игра сейчас недоступна');return}
  const m={me:true,type:'invite',game,accepted:false};addMsg(c,m);
  setTimeout(()=>{m.accepted=true;addMsg(c,{me:false,type:'text',text:'Принимаю вызов! 🔥'});if(cur&&cur.id===c.id)drawMsgs();if(startNow){startGame(game,c)}},1400);
}

/* ---------- games hub ---------- */
let opp=1;
function renderGames(){
  const ch=$('#chips');ch.innerHTML='';
  C.forEach(c=>{const b=el('button','chip');b.type='button';b.setAttribute('aria-pressed',String(c.id===opp));b.appendChild(avatar(c,'sm'));b.appendChild(document.createTextNode(c.name));b.onclick=()=>{opp=c.id;renderGames()};ch.appendChild(b)});
  const g=$('#gcards');g.innerHTML='';
  const shown=Catalog.games().filter(x=>x.enabled);
  if(!shown.length)g.appendChild(el('p','note','Сейчас нет доступных игр. Загляните позже.'));
  shown.forEach(x=>{
    const b=el('button','gcard'+(x.ready?'':' soon'));b.type='button';
    const ic=el('div','ic');ic.innerHTML=x.icon||'';
    const t=el('div','grow'),nm=el('b','',x.name);
    if(x.ready&&x.badge)nm.appendChild(el('span','gbadge'+(x.badge==='hot'?' hot':''),x.badge==='hot'?'Хит':'Новинка'));
    t.appendChild(nm);t.appendChild(el('span','',x.ready?x.desc:('Скоро'+(x.desc?'. '+x.desc:''))));
    b.append(ic,t);
    if(x.ready)b.onclick=()=>{const c=byId(opp);toast('Вызов отправлен: '+c.name);challenge(c,x.id,true)};
    else b.disabled=true;
    g.appendChild(b)});
}

/* ---------- game shell ---------- */
let gtok=0,cleanups=[];
function startGame(key,c){
  if(!Catalog.canPlay(key)){toast('Игра сейчас недоступна');return}
  closeGameQuiet();const tok=++gtok;
  $('#chat').hidden=true;cur=null;
  $('#game').hidden=false;$('#gTitle').textContent=G[key].name;$('#gSub').textContent='против '+c.name;
  const box=$('#gbody');box.innerHTML='';G[key].run(c,box,()=>gtok===tok,fn=>cleanups.push(fn),()=>startGame(key,c));
}
function closeGameQuiet(){gtok++;cleanups.forEach(f=>{try{f()}catch(e){}});cleanups=[]}
$('#gameBack').onclick=()=>{closeGameQuiet();$('#game').hidden=true;if(view==='chats')renderChats();else if(view==='map')renderMap()};
function result(box,title,sub,again){const r=el('div','result');r.appendChild(el('h3','',title));r.appendChild(el('p','',sub));
  const b=el('button','btn pri','Сыграть ещё');b.onclick=again;r.appendChild(b);box.appendChild(r)}

/* ---------- загрузка файлов и вход админа ---------- */
const _ls={};
function loadScript(src){
  return _ls[src]||(_ls[src]=new Promise((res,rej)=>{
    const s=document.createElement('script');s.src=src;s.onload=()=>res();
    s.onerror=()=>{delete _ls[src];rej(new Error('load '+src))};document.head.appendChild(s)}))}
function adminTaps(node){
  let n=0,t=0;
  node.addEventListener('click',()=>{const now=Date.now();n=(now-t<1500)?n+1:1;t=now;if(n>=APP.adminTaps){n=0;openAdmin()}})}
function openAdmin(){
  const go=()=>Admin.open();
  if(typeof Admin!=='undefined'){go();return}
  loadScript('js/admin.js').then(go).catch(()=>toast('Не удалось открыть админку'))}

/* ---------- объявления, обновления, предпросмотр ---------- */
const DISM='dosfaith.dismissed';
function dismissed(){try{return JSON.parse(Store.get(DISM)||'[]')}catch(e){return[]}}
function dismiss(id){const a=dismissed();if(a.indexOf(id)<0){a.push(id);Store.set(DISM,JSON.stringify(a.slice(-30)))}}
function banner(cls,text,action,onX){
  const d=el('div','nt '+cls);d.appendChild(el('span','ntx',text));
  if(action){
    const a=action.href?el('a','nbtn',action.label):el('button','nbtn',action.label);
    if(action.href){a.href=action.href;a.target='_blank';a.rel='noopener'}else{a.type='button';a.onclick=action.fn}
    d.appendChild(a)}
  if(onX){const x=el('button','nx','×');x.type='button';x.setAttribute('aria-label','Скрыть');x.onclick=onX;d.appendChild(x)}
  return d}
function renderNotice(){
  const box=$('#notice');box.innerHTML='';
  const u=Catalog.updateState(),f=$('#force');
  if(u.mode==='force'){
    $('#forceP').textContent=u.message||('Вышла новая версия. У вас '+APP.version+', нужна '+u.min+' или новее.');
    const go=$('#forceGo');if(u.storeUrl){go.href=u.storeUrl;go.hidden=false}else go.hidden=true;
    f.hidden=false}
  else f.hidden=true;
  if(Catalog.hasPreview())box.appendChild(banner('pv','Предпросмотр админа: изменения видны только на этом телефоне.',{label:'Админка',fn:openAdmin}));
  const a=Catalog.announcement();
  if(a&&dismissed().indexOf('a:'+a.id)<0)box.appendChild(banner(a.level==='warn'?'warn':'info',a.text,null,()=>{dismiss('a:'+a.id);renderNotice()}));
  if(u.mode==='soft'&&dismissed().indexOf('v:'+u.latest)<0)
    box.appendChild(banner('upd',u.message||('Доступна версия '+u.latest+'.'),u.storeUrl?{label:'Обновить',href:u.storeUrl}:null,()=>{dismiss('v:'+u.latest);renderNotice()}));
  box.hidden=!box.children.length}
