'use strict';
/* Запуск приложения: читает каталог, подгружает файлы игр из встроенного каталога, затем стартует.
   Новая игра = файл в js/games/ + запись в config/catalog.js (см. README). */
(async function(){
  try{
    Catalog.init();
    for(const g of Catalog.bundledFiles()){
      if(!G[g.id]){try{await loadScript(g.file)}catch(e){console.warn('Игра не загружена: '+g.id)}}
    }
    if(typeof startApp!=='function')await loadScript('js/app.js');
    startApp();
  }catch(e){
    console.error(e);
    const m=document.getElementById('main');
    if(m)m.textContent='Не удалось запустить приложение. Закройте и откройте его снова.';
  }
})();
