'use strict';
/* Админка DOS& FAITH. Файл подгружается только когда админ открывает вход (7 нажатий на логотип или адрес с #admin).

   О безопасности. Пока у приложения нет сервера, пароль админа защищает только этот телефон:
   он хранится здесь в виде хеша (PBKDF2), после 5 неверных попыток вход блокируется на время, через 15 минут
   без действий панель закрывается сама. Изменения из панели сначала видны только на этом телефоне.
   Всем пользователям их показывает только публикация файла config/catalog.js в вашем репозитории,
   а это защищено вашим аккаунтом GitHub. Когда появится сервер, роль админа нужно проверять на сервере. */
const Admin=(function(){
  const AK='dosfaith.admin.v1',LK='dosfaith.admin.lock',IDLE=15*60*1000,ITER=150000;
  const BADGE={new:'Новинка',hot:'Хит'};
  const enc=new TextEncoder();
  let until=0,tab='games',W=null,timer=null,login=null,panel=null,busy=false;

  /* ---------- пароль ---------- */
  const okCrypto=()=>!!(window.crypto&&crypto.subtle&&crypto.getRandomValues);
  const b64=u=>{let s='';new Uint8Array(u).forEach(x=>{s+=String.fromCharCode(x)});return btoa(s)};
  const unb64=s=>Uint8Array.from(atob(s),c=>c.charCodeAt(0));
  async function derive(pw,salt,iter){
    const k=await crypto.subtle.importKey('raw',enc.encode(pw),'PBKDF2',false,['deriveBits']);
    return b64(await crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',salt,iterations:iter},k,256))}
  const rec=()=>{try{const r=JSON.parse(Store.get(AK));return r&&r.hash&&r.salt&&r.iter?r:null}catch(e){return null}};
  const same=(a,b)=>{if(a.length!==b.length)return false;let d=0;for(let i=0;i<a.length;i++)d|=a.charCodeAt(i)^b.charCodeAt(i);return d===0};
  const lockState=()=>{try{return JSON.parse(Store.get(LK))||{fails:0,until:0}}catch(e){return{fails:0,until:0}}};
  async function createPw(pw){const salt=crypto.getRandomValues(new Uint8Array(16));Store.set(AK,JSON.stringify({salt:b64(salt),iter:ITER,hash:await derive(pw,salt,ITER)}))}
  async function check(pw){const r=rec();if(!r)return false;return same(await derive(pw,unb64(r.salt),r.iter),r.hash)}
  async function tryLogin(pw){
    const L=lockState(),now=Date.now();
    if(L.until>now)return{ok:false,wait:Math.ceil((L.until-now)/1000)};
    if(await check(pw)){Store.del(LK);return{ok:true}}
    const fails=(L.fails||0)+1;let u=0;
    if(fails>=5)u=now+Math.min(600,30*Math.pow(2,fails-5))*1000;
    Store.set(LK,JSON.stringify({fails,until:u}));
    return{ok:false,left:Math.max(0,5-fails),wait:u?Math.ceil((u-now)/1000):0}}
  const touch=()=>{until=Date.now()+IDLE};
  const unlocked=()=>Date.now()<until;

  /* ---------- оформление ---------- */
  function css(){
    if(document.getElementById('admCss'))return;
    const s=document.createElement('style');s.id='admCss';
    s.textContent=`
.adm{z-index:45}
.adm-in{flex:1;min-height:0;overflow-y:auto;width:100%;max-width:560px;margin:0 auto;padding:14px 0 28px;display:flex;flex-direction:column;gap:14px}
.adm-in.login{padding-top:24px}
.adm-h1{font-family:var(--font-display);font-size:22px;line-height:1.15;margin:8px 0 0;text-wrap:balance}
.adm-form{display:flex;flex-direction:column;gap:14px}
.adm-tabs{display:flex;gap:6px;overflow-x:auto;padding:8px 0;border-bottom:1px solid var(--line);width:100%;max-width:560px;margin:0 auto}
.adm-tab{flex:none;min-height:44px;padding:0 12px;border-radius:22px;border:1px solid var(--line);background:var(--surface);font-weight:700;font-size:14px}
.adm-tab[aria-selected="true"]{background:var(--accent);color:var(--on-accent);border-color:var(--accent)}
.adm-card{background:var(--surface);border:1px solid var(--line);border-radius:14px;padding:12px 14px;display:flex;flex-direction:column;gap:10px}
.adm-card h3{margin:0;font-family:var(--font-display);font-size:14px;font-weight:600}
.adm-hint{font-size:13px;color:var(--muted);margin:0}
.adm-row{display:flex;flex-wrap:wrap;align-items:center;gap:8px 12px;padding:12px 0;border-top:1px solid var(--line)}
.adm-row.first{border-top:0;padding-top:2px}
.adm-ic{flex:none;width:40px;height:40px;border-radius:10px;background:var(--surface2);display:grid;place-items:center;color:var(--fg)}
.adm-ic svg{width:26px;height:26px}
.adm-ctl{flex-basis:100%;display:flex;gap:8px;align-items:center;flex-wrap:wrap}
.adm-ctl .ib{width:44px;border:1px solid var(--line);background:var(--surface2);font-size:20px}
.adm-ctl .ib:disabled{opacity:.35}
.adm-sel{height:44px;border-radius:10px;border:1px solid var(--line);background:var(--surface);color:var(--fg);padding:0 10px;font:inherit}
.adm .fld textarea{border-radius:12px;border:1px solid var(--line);background:var(--surface);color:var(--fg);padding:12px 14px;font:inherit;font-size:16px;width:100%;min-width:0;resize:vertical;min-height:84px}
.adm .fld select{height:50px;border-radius:12px;border:1px solid var(--line);background:var(--surface);color:var(--fg);padding:0 12px;font:inherit;font-size:16px;width:100%}
.adm-code{width:100%;min-height:170px;border-radius:10px;border:1px solid var(--line);background:var(--surface2);color:var(--fg);font:12px/1.45 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;padding:10px;resize:vertical}
.adm-warn{color:var(--bad);font-size:13px;margin:0}
.adm-ok{color:var(--good);font-size:13px;font-weight:700;margin:0}
.adm-list{margin:0;padding-left:20px;display:flex;flex-direction:column;gap:6px;font-size:14px}
.adm-kv{display:flex;justify-content:space-between;gap:12px;font-size:14px}
.adm-kv span:first-child{color:var(--muted)}
.adm-kv span:last-child{font-weight:700;text-align:right;overflow-wrap:anywhere;min-width:0}
.adm-two{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px}
`;
    document.head.appendChild(s)}

  const h=(t,c,x)=>el(t,c,x);
  const clone=o=>JSON.parse(JSON.stringify(o));
  function btn(label,cls,fn){const b=h('button','btn'+(cls?' '+cls:''),label);b.type='button';b.onclick=fn;return b}
  function field(id,label,type,ac,props){
    const w=h('div','fld'),l=h('label','',label);l.htmlFor=id;
    const i=document.createElement(type==='textarea'?'textarea':'input');i.id=id;
    if(type!=='textarea')i.type=type;if(ac)i.autocomplete=ac;if(props)Object.assign(i,props);
    w.append(l,i);return{w,i}}
  function select(id,label,opts,val){
    const w=h('div','fld'),l=h('label','',label);l.htmlFor=id;const s=document.createElement('select');s.id=id;
    opts.forEach(o=>{const op=document.createElement('option');op.value=o[0];op.textContent=o[1];if(o[0]===val)op.selected=true;s.appendChild(op)});
    w.append(l,s);return{w,i:s}}
  function build(){
    css();if(login)return;
    login=h('div','screen adm');login.id='admLogin';login.hidden=true;
    panel=h('div','screen adm');panel.id='adm';panel.hidden=true;
    panel.addEventListener('pointerdown',touch,true);panel.addEventListener('keydown',touch,true);
    document.body.append(login,panel)}

  /* ---------- вход ---------- */
  function showLogin(){
    build();panel.hidden=true;stopTimer();
    const first=!rec();
    login.innerHTML='';login.hidden=false;
    const box=h('div','adm-in login');
    const logo=h('div','word big');logo.innerHTML='DOS<i>&amp;</i> FAITH';
    box.append(logo,h('h1','adm-h1',first?'Первый вход администратора':'Вход для администратора'),
      h('p','regp',first?'Придумайте пароль админа, не меньше 8 символов. Он хранится только на этом телефоне.':'Введите пароль админа.'));
    const f=document.createElement('form');f.className='adm-form';f.noValidate=true;
    const p1=field('admPw',first?'Новый пароль':'Пароль','password',first?'new-password':'current-password');
    const p2=first?field('admPw2','Повторите пароль','password','new-password'):null;
    const err=h('div','err');err.setAttribute('role','alert');
    const go=h('button','btn pri wide',first?'Создать и войти':'Войти');go.type='submit';
    const cl=h('button','lnk','Закрыть');cl.type='button';cl.onclick=close;
    f.append(p1.w);if(p2)f.append(p2.w);f.append(err,go,cl);
    f.onsubmit=async e=>{
      e.preventDefault();if(busy)return;err.textContent='';
      const pw=p1.i.value;
      if(!okCrypto()){err.textContent='Этот браузер не поддерживает защищённый вход.';return}
      if(first){
        if(pw.length<8){err.textContent='Пароль короче 8 символов';p1.i.focus();return}
        if(pw!==p2.i.value){err.textContent='Пароли не совпадают';p2.i.focus();return}
      }else if(!pw){err.textContent='Введите пароль';p1.i.focus();return}
      busy=true;go.disabled=true;
      try{
        if(first){await createPw(pw);touch();showPanel()}
        else{
          const r=await tryLogin(pw);
          if(r.ok){touch();showPanel()}
          else if(r.wait)err.textContent='Слишком много попыток. Подождите '+r.wait+' с.';
          else err.textContent='Неверный пароль. Осталось попыток до паузы: '+r.left;
        }
      }catch(x){err.textContent='Не удалось выполнить вход'}
      busy=false;go.disabled=false;p1.i.value='';if(p2)p2.i.value='';
    };
    box.appendChild(f);login.appendChild(box);
    setTimeout(()=>p1.i.focus(),50)}

  function showPanel(){
    build();login.hidden=true;panel.hidden=false;
    W=clone(Catalog.working());
    const have={};W.games.forEach(g=>{have[g.id]=1});
    Object.keys(G).forEach(id=>{if(!have[id])W.games.push({id,file:'',enabled:true,order:(W.games.length+1)*10,badge:'',name:'',desc:''})});
    tab='games';render(false);startTimer()}
  function close(){until=0;stopTimer();if(login)login.hidden=true;if(panel)panel.hidden=true}
  function startTimer(){stopTimer();timer=setInterval(()=>{if(panel&&!panel.hidden&&!unlocked()){toast('Вход закрыт из-за бездействия');showLogin()}},5000)}
  function stopTimer(){if(timer){clearInterval(timer);timer=null}}
  function open(){build();if(unlocked()&&panel.hidden===false)return;showLogin()}

  /* ---------- общее для вкладок ---------- */
  function commit(){Catalog.setPreview(W)}
  const sorted=()=>W.games.slice().sort((a,b)=>a.order-b.order||(a.id<b.id?-1:1));
  const gname=g=>(G[g.id]&&G[g.id].name)||g.name||g.id;
  function render(keep){
    const prev=panel.querySelector('.adm-in'),st=keep&&prev?prev.scrollTop:0;
    panel.innerHTML='';
    const hd=h('header','shead');
    const back=h('button','ib','‹');back.type='button';back.setAttribute('aria-label','Закрыть админку');back.onclick=close;
    const tt=h('div','grow');tt.append(h('div','gtitle','Админ'),h('div','sub','Версия приложения '+APP.version));
    hd.append(back,tt);panel.appendChild(hd);
    const tabs=h('div','adm-tabs');tabs.setAttribute('role','tablist');
    [['games','Игры'],['msg','Сообщения'],['pub','Публикация'],['acc','Доступ']].forEach(([k,t])=>{
      const b=h('button','adm-tab',t);b.type='button';b.setAttribute('role','tab');b.setAttribute('aria-selected',String(k===tab));
      b.onclick=()=>{tab=k;render(false)};tabs.appendChild(b)});
    panel.appendChild(tabs);
    const body=h('div','adm-in');
    ({games:tabGames,msg:tabMsg,pub:tabPub,acc:tabAcc})[tab](body);
    panel.appendChild(body);body.scrollTop=st}

  /* ---------- вкладка «Игры» ---------- */
  function move(id,dir){
    const a=sorted(),i=a.findIndex(x=>x.id===id),j=i+dir;if(j<0||j>=a.length)return;
    [a[i],a[j]]=[a[j],a[i]];a.forEach((x,k)=>{x.order=(k+1)*10});W.games=a;commit();render(true)}
  const iconBtn=(t,label,fn,dis)=>{const b=h('button','ib',t);b.type='button';b.setAttribute('aria-label',label);b.disabled=!!dis;b.onclick=fn;return b};
  function tabGames(body){
    const card=h('div','adm-card');
    card.append(h('h3','','Игры в приложении'),
      h('p','adm-hint','Выключенная игра пропадает у пользователей. Изменения сразу видны на этом телефоне, остальным они придут после публикации.'));
    const list=sorted();
    list.forEach((g,i)=>{
      const code=G[g.id],name=gname(g);
      const row=h('div','adm-row'+(i===0?' first':''));
      const ic=h('div','adm-ic');
      ic.innerHTML=code?code.icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="8" stroke-dasharray="3 3"/></svg>';
      const info=h('div','grow');info.append(h('div','nm',name),h('div','sub',g.id+' · '+(code?'есть в приложении':'анонс, кода пока нет')));
      const sw=h('button','sw');sw.type='button';sw.setAttribute('role','switch');sw.setAttribute('aria-checked',String(g.enabled));
      sw.setAttribute('aria-label','Показывать игру «'+name+'»');
      sw.onclick=()=>{g.enabled=!g.enabled;commit();render(true)};
      row.append(ic,info,sw);
      const ctl=h('div','adm-ctl');
      const bs=document.createElement('select');bs.className='adm-sel';bs.setAttribute('aria-label','Отметка для игры «'+name+'»');
      [['','Без отметки'],['new','Новинка'],['hot','Хит']].forEach(o=>{const op=document.createElement('option');op.value=o[0];op.textContent=o[1];if(o[0]===g.badge)op.selected=true;bs.appendChild(op)});
      bs.onchange=()=>{g.badge=bs.value;commit();render(true)};
      ctl.append(iconBtn('↑','Поднять выше',()=>move(g.id,-1),i===0),iconBtn('↓','Опустить ниже',()=>move(g.id,1),i===list.length-1),bs);
      if(!code)ctl.append(btn('Удалить','',()=>{W.games=W.games.filter(x=>x.id!==g.id);commit();render(true)}));
      row.appendChild(ctl);
      if(!code){
        const two=h('div','adm-two');two.style.flexBasis='100%';
        const n=field('admN-'+g.id,'Название','text','off',{value:g.name,maxLength:40});
        const d=field('admD-'+g.id,'Описание','text','off',{value:g.desc,maxLength:80});
        n.i.onchange=()=>{g.name=n.i.value.trim();commit();render(true)};d.i.onchange=()=>{g.desc=d.i.value.trim();commit()};
        two.append(n.w,d.w);row.appendChild(two)}
      card.appendChild(row)});
    body.appendChild(card);

    const add=h('div','adm-card');
    add.append(h('h3','','Анонсировать новую игру'),
      h('p','adm-hint','Игра появится у пользователей с пометкой «Скоро». Когда код игры с таким же идентификатором попадёт в приложение, она станет доступной сама.'));
    const fid=field('admNewId','Идентификатор: латиница, цифры и дефис','text','off',{maxLength:24,placeholder:'domino'});
    const fn=field('admNewName','Название','text','off',{maxLength:40,placeholder:'Домино'});
    const fd=field('admNewDesc','Описание (по желанию)','text','off',{maxLength:80,placeholder:'Классическое домино на двоих'});
    const err=h('div','err');err.setAttribute('role','alert');
    add.append(fid.w,fn.w,fd.w,err,btn('Добавить анонс','pri',()=>{
      const id=fid.i.value.trim().toLowerCase(),nm=fn.i.value.trim();
      if(!/^[a-z0-9-]{2,24}$/.test(id)){err.textContent='Идентификатор: 2–24 символа, латиница, цифры, дефис';return}
      if(W.games.some(x=>x.id===id)){err.textContent='Такая игра уже есть в списке';return}
      if(!nm&&!G[id]){err.textContent='Укажите название';return}
      W.games.push({id,file:'',enabled:true,order:(W.games.length+1)*10,badge:'new',name:nm,desc:fd.i.value.trim()});
      commit();toast('Анонс добавлен');render(true)}));
    body.appendChild(add);

    const how=h('div','adm-card');how.append(h('h3','','Как добавить игру в код'));
    const ol=h('ol','adm-list');
    ['Положить файл игры в www/js/games, например domino.js. Образец: любой соседний файл.',
     'В конце файла вызвать registerGame с тем же идентификатором, названием, описанием и иконкой.',
     'Добавить в www/config/catalog.js строку игры с полем file. Если анонс уже есть, достаточно дописать file.',
     'Выложить изменения в репозиторий и выпустить обновление. Пользователи получат игру вместе с ним.'].forEach(t=>ol.appendChild(h('li','',t)));
    how.appendChild(ol);body.appendChild(how)}

  /* ---------- вкладка «Сообщения» ---------- */
  function tabMsg(body){
    const a=W.announcement;
    const c1=h('div','adm-card');c1.append(h('h3','','Объявление для всех'),
      h('p','adm-hint','Полоса с текстом над основным экраном. Пользователь может её закрыть, новое объявление покажется снова.'));
    const tx=field('admAnnText','Текст (до 240 символов)','textarea',null,{value:a.text,maxLength:240,rows:3});
    const lv=select('admAnnLevel','Вид',[['info','Обычное'],['warn','Важное']],a.level);
    const fr=field('admAnnFrom','Показывать с (по желанию)','date',null,{value:a.from});
    const to=field('admAnnTo','Показывать до (по желанию)','date',null,{value:a.to});
    const dates=h('div','adm-two');dates.append(fr.w,to.w);
    const err=h('div','err');err.setAttribute('role','alert');
    const row=h('div','btns');
    row.append(btn('Включить объявление','pri',()=>{
      const t=tx.i.value.trim();if(!t){err.textContent='Введите текст объявления';tx.i.focus();return}
      if(fr.i.value&&to.i.value&&to.i.value<fr.i.value){err.textContent='Дата окончания раньше даты начала';return}
      W.announcement={id:'a'+Date.now().toString(36),text:t,level:lv.i.value,from:fr.i.value,to:to.i.value};
      commit();toast('Объявление включено на этом телефоне');render(true)}),
      btn('Снять','',()=>{W.announcement={id:'',text:'',level:'info',from:'',to:''};commit();toast('Объявление снято');render(true)}));
    c1.append(tx.w,lv.w,dates,err,row);body.appendChild(c1);

    const v=W.app;
    const c2=h('div','adm-card');c2.append(h('h3','','Версии приложения'),
      h('p','adm-hint','Последняя версия: пользователям со старой покажется предложение обновить. Минимальная: старые версии перестанут запускаться, пока не обновятся. Пользоваться этим стоит осторожно.'));
    const kv=h('div','adm-kv');kv.append(h('span','','Версия на этом телефоне'),h('span','',APP.version));
    const fl=field('admVerLatest','Последняя версия','text','off',{value:v.latest,placeholder:'0.3.0',maxLength:12,inputMode:'decimal'});
    const fm=field('admVerMin','Минимальная версия','text','off',{value:v.min,placeholder:'0.1.0',maxLength:12,inputMode:'decimal'});
    const ft=field('admVerMsg','Сообщение (по желанию)','text','off',{value:v.message,maxLength:200,placeholder:'Что нового в версии'});
    const fu=field('admVerUrl','Ссылка на приложение в магазине (https)','url','off',{value:v.storeUrl,placeholder:'https://play.google.com/store/apps/details?id=...'});
    const warn=h('p','adm-warn');warn.setAttribute('role','alert');
    const two=h('div','adm-two');two.append(fl.w,fm.w);
    const upd=()=>{
      const L=fl.i.value.trim(),M=fm.i.value.trim(),U=fu.i.value.trim(),ok=/^\d+(\.\d+){0,2}$/;
      if(L&&!ok.test(L)){warn.textContent='Последняя версия: формат вроде 0.3.0';return}
      if(M&&!ok.test(M)){warn.textContent='Минимальная версия: формат вроде 0.1.0';return}
      if(U&&!/^https:\/\/[^\s"<>]+$/.test(U)){warn.textContent='Ссылка должна начинаться с https://';return}
      W.app={latest:L,min:M,message:ft.i.value.trim(),storeUrl:U};
      const msgs=[];
      if(L&&M&&Catalog.cmp(M,L)>0)msgs.push('Минимальная версия выше последней: так пользователям будет не обновиться.');
      if(M&&Catalog.cmp(APP.version,M)<0)msgs.push('Ваша версия '+APP.version+' ниже минимальной: на этом телефоне приложение закроется экраном обновления. Чтобы вернуться, нажмите на логотип 7 раз и сбросьте предпросмотр.');
      warn.textContent=msgs.join(' ');commit()};
    [fl,fm,ft,fu].forEach(f=>{f.i.onchange=upd});
    c2.append(kv,two,ft.w,fu.w,warn);body.appendChild(c2)}

  /* ---------- вкладка «Публикация» ---------- */
  function changes(a,b){
    const out=[],A={},B={};a.games.forEach(g=>{A[g.id]=g});b.games.forEach(g=>{B[g.id]=g});
    const nm=(g)=>(G[g.id]&&G[g.id].name)||g.name||g.id;
    Object.keys(B).forEach(id=>{const x=A[id],y=B[id];
      if(!x){out.push('Добавлена игра «'+nm(y)+'»'+(y.enabled?'':' (выключена)'));return}
      if(x.enabled!==y.enabled)out.push('Игра «'+nm(y)+'»: '+(y.enabled?'включена':'выключена'));
      if(x.badge!==y.badge)out.push('Игра «'+nm(y)+'»: '+(y.badge?'отметка «'+BADGE[y.badge]+'»':'отметка снята'));
      if(!G[id]&&(x.name!==y.name||x.desc!==y.desc))out.push('Игра «'+nm(y)+'»: изменено название или описание')});
    Object.keys(A).forEach(id=>{if(!B[id])out.push('Удалена запись «'+nm(A[id])+'»')});
    const ord=(l,o)=>l.slice().sort((p,q)=>p.order-q.order||(p.id<q.id?-1:1)).map(g=>g.id).filter(id=>o[id]).join();
    if(ord(a.games,B)!==ord(b.games,A))out.push('Изменён порядок игр');
    const an=a.announcement,bn=b.announcement;
    if(an.text!==bn.text||an.level!==bn.level||an.from!==bn.from||an.to!==bn.to)
      out.push(bn.text?'Объявление: «'+bn.text.slice(0,50)+(bn.text.length>50?'…':'')+'»':'Объявление снято');
    if(a.app.latest!==b.app.latest||a.app.min!==b.app.min)out.push('Версии: последняя '+(b.app.latest||'не задана')+', минимальная '+(b.app.min||'не задана'));
    if(a.app.message!==b.app.message||a.app.storeUrl!==b.app.storeUrl)out.push('Изменено сообщение об обновлении или ссылка на магазин');
    return out}
  const outObj=()=>{const o=clone(W);o.rev=Math.max(Catalog.loaded().rev,0)+1;o.updatedAt=Catalog.today();return o};
  function tabPub(body){
    const st=Catalog.status(),base=Catalog.loaded(),list=changes(base,W);
    const c1=h('div','adm-card');c1.appendChild(h('h3','','Что видят пользователи сейчас'));
    const kv=(k,v)=>{const d=h('div','adm-kv');d.append(h('span','',k),h('span','',v));return d};
    c1.append(kv('Откуда взят каталог',st.using==='preview'?'Предпросмотр на этом телефоне':(st.using==='remote'?'С сервера':'Встроенный')),
      kv('Версия встроенного каталога',String(st.bundledRev)),
      kv('Версия каталога с сервера',st.remoteRev?String(st.remoteRev):'не получена'),
      kv('Ссылка на сервер',st.url?(st.result==='ok'?'работает':(st.result==='fail'?'не открылась':'ещё не проверена')):'не задана'));
    body.appendChild(c1);

    const c2=h('div','adm-card');c2.appendChild(h('h3','','Что изменено'));
    if(list.length){const ul=h('ul','adm-list');list.forEach(t=>ul.appendChild(h('li','',t)));c2.appendChild(ul)}
    else c2.appendChild(h('p','adm-hint','Изменений нет. Опубликовать нечего.'));
    body.appendChild(c2);

    const o=outObj(),text=Catalog.serialize(o);
    const c3=h('div','adm-card');c3.append(h('h3','','Опубликовать для всех'),
      h('p','adm-hint','Пока вы не опубликуете изменения, их видите только вы на этом телефоне.'));
    const ol=h('ol','adm-list');
    ['Нажмите «Скопировать файл».',
     'Откройте на GitHub репозиторий, затем www/config/catalog.js и нажмите значок карандаша.',
     'Выделите весь текст, вставьте скопированный и нажмите Commit changes.',
     'Через несколько минут приложения подхватят каталог. Выпускать новую версию в магазин ради этого не нужно.'].forEach(t=>ol.appendChild(h('li','',t)));
    const ta=h('textarea','adm-code');ta.readOnly=true;ta.value=text;ta.setAttribute('aria-label','Текст файла catalog.js');ta.id='admOut';
    const ok=h('p','adm-ok');
    const row=h('div','btns');
    row.append(btn('Скопировать файл','pri',async()=>{
      W.rev=o.rev;W.updatedAt=o.updatedAt;commit();
      let done=false;
      try{await navigator.clipboard.writeText(text);done=true}catch(e){}
      if(!done){ta.focus();ta.select();try{done=document.execCommand('copy')}catch(e){}}
      ok.textContent=done?'Скопировано. Теперь вставьте в catalog.js на GitHub.':'Не удалось скопировать сам. Текст выделен ниже: скопируйте его вручную.'}),
      btn('Сбросить предпросмотр','',()=>{Catalog.setPreview(null);W=clone(Catalog.working());toast('Предпросмотр сброшен');render(true)}));
    c3.append(ol,row,ok,ta);body.appendChild(c3)}

  /* ---------- вкладка «Доступ» ---------- */
  function tabAcc(body){
    const c1=h('div','adm-card');c1.append(h('h3','','Вход администратора'),
      h('p','adm-hint','Панель закрывается сама через 15 минут без действий. После пяти неверных паролей вход ненадолго блокируется.'),
      btn('Выйти из админки','',close));
    body.appendChild(c1);

    const c2=h('div','adm-card');c2.appendChild(h('h3','','Сменить пароль'));
    const f=document.createElement('form');f.className='adm-form';f.noValidate=true;
    const o=field('admOld','Текущий пароль','password','current-password');
    const n1=field('admNew','Новый пароль','password','new-password');
    const n2=field('admNew2','Повторите новый пароль','password','new-password');
    const err=h('div','err');err.setAttribute('role','alert');const ok=h('p','adm-ok');
    const go=h('button','btn pri','Сменить пароль');go.type='submit';
    f.append(o.w,n1.w,n2.w,err,ok,go);
    f.onsubmit=async e=>{
      e.preventDefault();err.textContent='';ok.textContent='';
      if(!okCrypto()){err.textContent='Этот браузер не поддерживает защищённый вход.';return}
      if(n1.i.value.length<8){err.textContent='Новый пароль короче 8 символов';return}
      if(n1.i.value!==n2.i.value){err.textContent='Новые пароли не совпадают';return}
      go.disabled=true;
      try{
        if(!(await check(o.i.value)))err.textContent='Текущий пароль неверный';
        else{await createPw(n1.i.value);ok.textContent='Пароль изменён';o.i.value=n1.i.value=n2.i.value=''}
      }catch(x){err.textContent='Не удалось сменить пароль'}
      go.disabled=false};
    c2.appendChild(f);body.appendChild(c2);

    const c3=h('div','adm-card');c3.append(h('h3','','Что защищает этот вход'),
      h('p','adm-hint','Пароль хранится только на этом телефоне и закрывает админку здесь. Опубликовать изменения для всех можно только через ваш репозиторий на GitHub. Список пользователей, блокировки и общая модерация появятся вместе с сервером.'));
    body.appendChild(c3)}

  return{open,close};
})();
