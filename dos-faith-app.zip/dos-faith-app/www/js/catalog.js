'use strict';
/* Каталог игр, объявления и контроль версий.
   Источники по приоритету: предпросмотр админа (только этот телефон) > каталог с сервера > встроенный config/catalog.js.
   С сервера принимаются только данные: тексты, порядок, включение игр, версии. Код и ссылки на скрипты оттуда не берутся. */
const APP=Object.assign({version:'0.0.0',remoteCatalogUrl:'',fetchTimeoutMs:4000,adminTaps:7},window.DF_APP||{});

const Store=(function(){
  const mem={};
  return{
    get(k){try{const v=localStorage.getItem(k);if(v!==null)return v}catch(e){}return Object.prototype.hasOwnProperty.call(mem,k)?mem[k]:null},
    set(k,v){mem[k]=v;try{localStorage.setItem(k,v)}catch(e){}},
    del(k){delete mem[k];try{localStorage.removeItem(k)}catch(e){}}
  };
})();

const Catalog=(function(){
  const K_REMOTE='dosfaith.catalog.remote',K_PREVIEW='dosfaith.catalog.preview';
  const HEADER='/* Каталог игр и сообщений DOS& FAITH.\n   Файл читает приложение при запуске и, если в app.config.js задана ссылка remoteCatalogUrl, скачивает заново с сервера.\n   Правится вручную или через админку: вкладка «Публикация» выдаёт готовый текст файла целиком.\n   Здесь только данные. Код игр лежит в js/games. */\n';
  const subs=[];
  const str=(v,n)=>typeof v==='string'?v.trim().slice(0,n):'';
  const ver=v=>typeof v==='string'&&/^\d+(\.\d+){0,2}$/.test(v.trim())?v.trim():'';
  const day=v=>typeof v==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(v)?v:'';
  const cmp=(a,b)=>{const x=(a||'0').split('.').map(Number),y=(b||'0').split('.').map(Number);for(let i=0;i<3;i++){const d=(x[i]||0)-(y[i]||0);if(d)return d<0?-1:1}return 0};
  const today=()=>{const d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')};
  const clone=o=>JSON.parse(JSON.stringify(o));

  /* Проверка любых входных данных: лишнее отбрасывается, тексты ограничиваются по длине. */
  function clean(o,keepFile){
    const r={schema:1,rev:0,updatedAt:'',app:{latest:'',min:'',storeUrl:'',message:''},announcement:{id:'',text:'',level:'info',from:'',to:''},games:[]};
    if(!o||typeof o!=='object')return r;
    r.rev=Math.max(0,parseInt(o.rev,10)||0);r.updatedAt=day(o.updatedAt);
    const a=o.app&&typeof o.app==='object'?o.app:{};
    r.app.latest=ver(a.latest);r.app.min=ver(a.min);
    r.app.storeUrl=/^https:\/\/[^\s"<>]+$/.test(a.storeUrl||'')?a.storeUrl.slice(0,300):'';
    r.app.message=str(a.message,200);
    const n=o.announcement&&typeof o.announcement==='object'?o.announcement:{};
    r.announcement={id:str(n.id,24).replace(/[^\w-]/g,''),text:str(n.text,240),level:n.level==='warn'?'warn':'info',from:day(n.from),to:day(n.to)};
    const seen={};
    (Array.isArray(o.games)?o.games:[]).slice(0,60).forEach(g=>{
      if(!g||typeof g!=='object')return;
      const id=String(g.id||'');if(!/^[a-z0-9-]{2,24}$/.test(id)||seen[id])return;seen[id]=1;
      r.games.push({id,
        file:keepFile&&/^js\/games\/[a-z0-9-]+\.js$/.test(g.file||'')?g.file:'',
        enabled:g.enabled!==false,
        order:isFinite(+g.order)?+g.order:100,
        badge:g.badge==='new'||g.badge==='hot'?g.badge:'',
        name:str(g.name,40),desc:str(g.desc,80)});
    });
    return r}

  const bundled=clean(window.DF_CATALOG,true);
  let remote=null,preview=null;
  const state={result:'none'};

  const loaded=()=>remote&&remote.rev>bundled.rev?remote:bundled;
  const working=()=>preview||loaded();
  const emit=()=>subs.forEach(f=>{try{f()}catch(e){}});

  /* Каталог вместе с играми, у которых код есть, а записи в каталоге нет. */
  function withRegistered(c){
    const r=clone(c),have={};r.games.forEach(g=>have[g.id]=1);
    Object.keys(G).forEach(id=>{if(!have[id])r.games.push({id,file:'',enabled:true,order:1000,badge:'',name:'',desc:''})});
    return r}
  const sig=c=>{const w=withRegistered(c);
    return JSON.stringify([w.app,w.announcement,w.games.slice().sort((a,b)=>a.order-b.order||(a.id<b.id?-1:1)).map(g=>[g.id,g.enabled,g.badge,g.name,g.desc])])};

  function games(){
    const list=withRegistered(working()).games;
    list.forEach(g=>{const d=G[g.id];g.ready=!!d;g.name=(d&&d.name)||g.name||g.id;g.desc=(d&&d.desc)||g.desc||'';g.icon=d?d.icon:''});
    return list.sort((a,b)=>a.order-b.order||(a.id<b.id?-1:1))}
  const find=id=>games().find(g=>g.id===id);

  function announcement(){
    const a=working().announcement;if(!a.text)return null;
    const t=today();if(a.from&&t<a.from)return null;if(a.to&&t>a.to)return null;return a}

  function updateState(){
    const a=working().app,v=APP.version;
    const base={latest:a.latest,min:a.min,message:a.message,storeUrl:a.storeUrl};
    if(a.min&&cmp(v,a.min)<0)return Object.assign({mode:'force'},base);
    if(a.latest&&cmp(v,a.latest)<0)return Object.assign({mode:'soft'},base);
    return Object.assign({mode:'none'},base)}

  function parse(txt){const a=txt.indexOf('{'),b=txt.lastIndexOf('}');if(a<0||b<a)return null;try{return JSON.parse(txt.slice(a,b+1))}catch(e){return null}}

  async function refresh(){
    const url=APP.remoteCatalogUrl;
    if(!url||typeof fetch!=='function'){state.result='none';return false}
    const ctl=typeof AbortController==='function'?new AbortController():null;
    const timer=setTimeout(()=>{if(ctl)ctl.abort()},APP.fetchTimeoutMs);
    try{
      const r=await fetch(url+(url.indexOf('?')<0?'?':'&')+'t='+Math.floor(Date.now()/60000),{cache:'no-store',signal:ctl?ctl.signal:undefined});
      if(!r.ok){state.result='fail';return false}
      const txt=await r.text();if(txt.length>200000){state.result='fail';return false}
      const raw=parse(txt);if(!raw){state.result='fail';return false}
      const c=clean(raw);if(!c.rev||!c.games.length){state.result='fail';return false}
      remote=c;state.result='ok';Store.set(K_REMOTE,JSON.stringify(c));
      if(preview&&c.rev>=preview.rev){preview=null;Store.del(K_PREVIEW)}
      emit();return true;
    }catch(e){state.result='fail';return false}
    finally{clearTimeout(timer)}}

  function init(){
    try{const r=Store.get(K_REMOTE);if(r)remote=clean(JSON.parse(r))}catch(e){remote=null}
    try{const p=Store.get(K_PREVIEW);if(p)preview=clean(JSON.parse(p))}catch(e){preview=null}}

  function setPreview(obj){
    if(!obj){preview=null;Store.del(K_PREVIEW);emit();return}
    const c=clean(obj);
    if(sig(c)===sig(loaded())){preview=null;Store.del(K_PREVIEW)}
    else{preview=c;Store.set(K_PREVIEW,JSON.stringify(c))}
    emit()}

  /* Готовый текст файла config/catalog.js */
  function serialize(o){
    const c=clone(o);
    c.games=c.games.map(g=>{
      const b=bundled.games.find(x=>x.id===g.id);
      const file=(b&&b.file)||(G[g.id]?'js/games/'+g.id+'.js':'');
      const r={id:g.id};if(file)r.file=file;
      r.enabled=g.enabled;r.order=g.order;r.badge=g.badge;
      if(g.name&&!G[g.id])r.name=g.name;if(g.desc&&!G[g.id])r.desc=g.desc;
      return r});
    const lines=c.games.map(g=>'    '+JSON.stringify(g)).join(',\n');
    const body=JSON.stringify(Object.assign({},c,{games:'@@'}),null,2).replace('"@@"','[\n'+lines+'\n  ]');
    return HEADER+'window.DF_CATALOG = '+body+';\n'}

  return{
    init,refresh,games,find,announcement,updateState,working,loaded,setPreview,serialize,cmp,today,clean,clone,
    onChange:f=>subs.push(f),
    hasPreview:()=>!!preview,
    bundledFiles:()=>bundled.games.filter(g=>g.file).map(g=>({id:g.id,file:g.file})),
    nameOf:id=>{const g=find(id);return g?g.name:id},
    canPlay:id=>{const g=find(id);return !!(g&&g.enabled&&g.ready)},
    playable:()=>games().filter(g=>g.enabled&&g.ready),
    status:()=>({url:APP.remoteCatalogUrl,result:state.result,remoteRev:remote?remote.rev:0,bundledRev:bundled.rev,
      using:preview?'preview':(remote&&remote.rev>bundled.rev?'remote':'bundled')})
  };
})();
