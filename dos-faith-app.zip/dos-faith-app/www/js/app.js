'use strict';
/* ---------- profile and registration ---------- */
const PKEY='dosfaith.profile';
let profile=null,regEdit=false;
try{const raw=localStorage.getItem(PKEY);if(raw)profile=JSON.parse(raw)}catch(e){profile=null}
const rg=$('#reg');
const digits=s=>s.replace(/\D/g,'');
function fmtPhone(v){const t=v.trim();if(!t)return '';
  const d=digits(t);let local;
  if(t.startsWith('+')&&!t.startsWith('+7'))return '+'+d.slice(0,15);
  if(t.startsWith('+7'))local=d.slice(1,11);
  else if(d.length>=11&&(d[0]==='7'||d[0]==='8'))local=d.slice(1,11);
  else local=d.slice(0,10);
  let o='+7';if(local)o+=' '+local.slice(0,3);if(local.length>3)o+=' '+local.slice(3,6);if(local.length>6)o+=' '+local.slice(6,8);if(local.length>8)o+=' '+local.slice(8,10);
  return o}
function phoneOk(v){const t=v.trim(),d=digits(v);if(t.startsWith('+')&&!t.startsWith('+7'))return d.length>=8&&d.length<=15;return d.length===11}
function ageOf(s){const m=/^(\d{4})-(\d{2})-(\d{2})$/.exec(s);if(!m)return -1;
  const y=+m[1],mo=+m[2],da=+m[3],dt=new Date(y,mo-1,da);
  if(dt.getFullYear()!==y||dt.getMonth()!==mo-1||dt.getDate()!==da||y<1900)return -1;
  const n=new Date();let a=n.getFullYear()-y;if(n.getMonth()<mo-1||(n.getMonth()===mo-1&&n.getDate()<da))a--;return a}
function setErr(inp,err,text){$('#'+err).textContent=text||'';$('#'+inp).setAttribute('aria-invalid',text?'true':'false')}
function applyProfile(){$('#hdrUser').textContent=profile?profile.first+' '+profile.last.charAt(0)+'.':'дос — друг'}
function openReg(edit){regEdit=edit;
  $('#regH').textContent=edit?'Ваш профиль':'Создайте профиль';
  $('#regP').textContent=edit?'Измените данные и сохраните.':'Достаточно номера телефона, имени, фамилии и даты рождения. Почта по желанию.';
  $('#regGo').textContent=edit?'Сохранить':'Продолжить';
  $('#regClose').hidden=!edit;$('#regOut').hidden=!edit;
  const p=edit&&profile?profile:{first:'',last:'',phone:'',dob:'',email:''};
  $('#rgFirst').value=p.first;$('#rgLast').value=p.last;$('#rgPhone').value=p.phone?fmtPhone(p.phone):'+7';$('#rgDob').value=p.dob;$('#rgMail').value=p.email||'';
  [['rgFirst','eFirst'],['rgLast','eLast'],['rgPhone','ePhone'],['rgDob','eDob'],['rgMail','eMail']].forEach(x=>setErr(x[0],x[1],''));
  rg.hidden=false;$('.regin').scrollTop=0}
$('#rgPhone').addEventListener('input',e=>{e.target.value=fmtPhone(e.target.value)});
$('#regForm').addEventListener('submit',e=>{e.preventDefault();
  const first=$('#rgFirst').value.trim(),last=$('#rgLast').value.trim(),phone=$('#rgPhone').value,dob=$('#rgDob').value,mail=$('#rgMail').value.trim();
  const age=ageOf(dob);let bad=null;
  const chk=(id,eid,ok,text)=>{setErr(id,eid,ok?'':text);if(!ok&&!bad)bad=id};
  chk('rgFirst','eFirst',/\p{L}/u.test(first),'Введите имя');
  chk('rgLast','eLast',/\p{L}/u.test(last),'Введите фамилию');
  chk('rgPhone','ePhone',phoneOk(phone),'Проверьте номер телефона');
  chk('rgDob','eDob',age>=0,dob?'Проверьте дату рождения':'Укажите дату рождения');
  if(age>=0)chk('rgDob','eDob',age>=13,'Приложение для пользователей от 13 лет');
  chk('rgMail','eMail',!mail||/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(mail),'Проверьте адрес почты');
  if(bad){$('#'+bad).focus();return}
  profile={first,last,phone:'+'+digits(phone),dob,email:mail};
  try{localStorage.setItem(PKEY,JSON.stringify(profile))}catch(err){}
  rg.hidden=true;applyProfile();toast(regEdit?'Профиль сохранён':'Добро пожаловать, '+first+'!')});
$('#hdrUser').addEventListener('click',()=>{if(profile)openReg(true)});
$('#regClose').addEventListener('click',()=>{rg.hidden=true});
$('#regOut').addEventListener('click',()=>{try{localStorage.removeItem(PKEY)}catch(err){}profile=null;applyProfile();openReg(false)});

/* ---------- запуск (вызывает boot.js после загрузки игр) ---------- */
function startApp(){
  $('#appVer').textContent='Версия '+APP.version;
  Catalog.onChange(()=>{renderNotice();if(view==='games')renderGames()});
  document.querySelectorAll('.word').forEach(adminTaps);
  window.addEventListener('hashchange',()=>{if(location.hash==='#admin')openAdmin()});
  renderNotice();renderMap();updBadge();applyProfile();
  if(!profile)openReg(false);
  if(location.hash==='#admin')openAdmin();
  Catalog.refresh();
}
